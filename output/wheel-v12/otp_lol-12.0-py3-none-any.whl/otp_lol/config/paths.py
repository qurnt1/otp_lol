"""
FILE NAME: src/otp_lol/config/paths.py
GLOBAL PURPOSE:
- Resolve filesystem paths used by the application at runtime.
- Bridge local source execution and PyInstaller execution through one resource helper.
- Define stable locations for settings, history, caches, and temporary files.

KEY FUNCTIONS:
- resource_path: Resolve an asset path for source runs and packaged runs.
- get_appdata_path: Build a file path inside the user AppData folder when available.

AUDIENCE & LOGIC:
Why:
This module exists so every runtime path is built from one consistent place instead of being duplicated across the codebase.
For whom:
Developers working on filesystem access, caching, packaging, or resource loading.

DEPENDENCIES:
Used by:
- otp_lol.config, otp_lol.core, otp_lol.services, and otp_lol.ui modules that read files or write caches.
Uses:
- Standard library: os, sys, tempfile
"""

import os
import sys
import tempfile
from pathlib import Path

APP_STORAGE_FOLDER = "OTP LOL"
APP_TEMP_PREFIX = "otp_lol"


def resource_path(relative_path: str) -> str:
    """Return the absolute path to a bundled resource for source and packaged runs."""
    base_path = sys._MEIPASS if hasattr(sys, "_MEIPASS") else str(Path(__file__).resolve().parents[1])

    if relative_path.startswith("./") or relative_path.startswith(".\\"):
        relative_path = relative_path[2:]

    return os.path.join(base_path, relative_path)


def get_appdata_path(filename: str) -> str:
    """Return a stable writable path for an application-owned user file.

    The current working directory is deliberately never used as a fallback:
    it is not stable for shortcuts, PyInstaller windowed builds, or protected
    installation directories.
    """
    if os.path.basename(filename) != filename:
        raise ValueError("Application data filenames must not contain path separators.")

    candidates = [
        os.getenv("APPDATA"),
        os.getenv("LOCALAPPDATA"),
        tempfile.gettempdir(),
    ]
    attempted: list[str] = []
    for base_dir in candidates:
        if not base_dir or base_dir in attempted:
            continue
        attempted.append(base_dir)
        app_folder = os.path.join(base_dir, APP_STORAGE_FOLDER)
        try:
            os.makedirs(app_folder, exist_ok=True)
            if os.path.isdir(app_folder):
                return os.path.join(app_folder, filename)
        except OSError:
            continue

    raise OSError(f"Unable to create a writable {APP_STORAGE_FOLDER} data directory.")


PARAMETERS_PATH: str = get_appdata_path("parameters.toml")
PARAMETERS_JSON_PATH: str = get_appdata_path("parameters.json")
HISTORY_PATH: str = get_appdata_path("history.json")
LOCKFILE_PATH: str = os.path.join(tempfile.gettempdir(), f"{APP_TEMP_PREFIX}.lock")
DDRAGON_CACHE_FILE: str = os.path.join(tempfile.gettempdir(), f"{APP_TEMP_PREFIX}_ddragon_champions.json")
ICONS_CACHE_DIR: str = os.path.join(tempfile.gettempdir(), f"{APP_TEMP_PREFIX}_icons")
SPELLS_CACHE_DIR: str = os.path.join(tempfile.gettempdir(), f"{APP_TEMP_PREFIX}_spells")
SKINS_CACHE_DIR: str = os.path.join(tempfile.gettempdir(), f"{APP_TEMP_PREFIX}_skins")
RUNES_CACHE_DIR: str = os.path.join(tempfile.gettempdir(), f"{APP_TEMP_PREFIX}_runes")
