"""
FILE NAME: src/otp_lol/config/logging_config.py
GLOBAL PURPOSE:
- Configure application-wide logging once during import.
- Route logs to both a file and the current console stream.
- Expose the resolved log-file path to the rest of the application.

KEY FUNCTIONS:
- _setup_logging: Configure root logger handlers and return the final log path.

AUDIENCE & LOGIC:
Why:
This module exists so all runtime modules share the same logging format, output paths, and encoding behavior.
For whom:
Developers debugging runtime behavior or maintaining the logging setup.

DEPENDENCIES:
Used by:
- otp_lol.config.__init__ and any module importing `LOG_FILE_PATH`.
Uses:
- Standard library: logging, os, sys, tempfile
"""

import logging
import os
import sys
import tempfile
from contextlib import suppress
from logging.handlers import RotatingFileHandler

from .paths import get_appdata_path

MAX_LOG_BYTES = 5 * 1024 * 1024
LOG_BACKUP_COUNT = 3


def _setup_logging() -> str:
    """Configure root logging handlers and return the resolved log-file path."""
    try:
        log_path = get_appdata_path("app_debug.log")
    except OSError:
        log_path = os.path.join(tempfile.gettempdir(), "otp_lol_app_debug.log")

    # Reconfigure stdout when possible so console logs do not break on Unicode output.
    if hasattr(sys.stdout, "reconfigure"):
        with suppress(OSError, ValueError):
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")

    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)
    for handler in root_logger.handlers[:]:
        if getattr(handler, "_otp_lol_handler", False):
            root_logger.removeHandler(handler)
            handler.close()

    try:
        file_handler = RotatingFileHandler(
            log_path,
            maxBytes=MAX_LOG_BYTES,
            backupCount=LOG_BACKUP_COUNT,
            encoding="utf-8",
        )
    except OSError:
        log_path = os.path.join(tempfile.gettempdir(), "otp_lol_app_debug.log")
        file_handler = RotatingFileHandler(
            log_path,
            maxBytes=MAX_LOG_BYTES,
            backupCount=LOG_BACKUP_COUNT,
            encoding="utf-8",
        )
    file_handler.setLevel(logging.INFO)
    file_handler._otp_lol_handler = True
    file_handler.setFormatter(
        logging.Formatter("%(asctime)s - %(levelname)s - [%(filename)s:%(lineno)d] - %(message)s")
    )

    root_logger.addHandler(file_handler)

    console_stream = sys.stdout or sys.stderr
    if console_stream is not None:
        console_handler = logging.StreamHandler(console_stream)
        console_handler.setLevel(logging.INFO)
        console_handler._otp_lol_handler = True
        console_handler.setFormatter(logging.Formatter("[%(asctime)s] %(message)s", datefmt="%H:%M:%S"))
        root_logger.addHandler(console_handler)

    return log_path


LOG_FILE_PATH: str = _setup_logging()
