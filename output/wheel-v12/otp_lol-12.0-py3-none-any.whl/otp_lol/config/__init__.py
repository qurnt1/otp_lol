"""
FILE NAME: src/otp_lol/config/__init__.py
GLOBAL PURPOSE:
- Provide the public configuration API for the application.
- Re-export constants, paths, and settings helpers from the config package.
- Keep runtime path synchronization centralized before settings helpers are called.

KEY FUNCTIONS:
- load_parameters: Load normalized application settings.
- save_parameters: Persist normalized application settings.
- get_cache_dirs: Ensure cache directories exist before use.

AUDIENCE & LOGIC:
Why:
This module exists as the single import surface for configuration so callers do not need to know how the package is internally split.
For whom:
Developers importing configuration values, settings helpers, or resource paths.

DEPENDENCIES:
Used by:
- otp_lol.__main__ and most runtime modules under `src`.
Uses:
- Local modules: otp_lol.config.constants, otp_lol.config.logging_config, otp_lol.config.paths, otp_lol.config.settings
"""

from . import settings as _settings
from .constants import (
    APP_BUILD_NAME,
    APP_IMAGE_FILES,
    APP_NAME,
    CONFIG_SCHEMA_VERSION,
    CURRENT_VERSION,
    EP_CHAT_ME,
    EP_CS_RUNE_PAGE,
    EP_CURRENT_SUMMONER,
    EP_GAMEFLOW,
    EP_LOBBY,
    EP_LOGIN,
    EP_PERKS_CURRENT_PAGE,
    EP_PERKS_INVENTORY,
    EP_PERKS_PAGES,
    EP_PERKS_STYLES,
    EP_PICKABLE,
    EP_READY_CHECK,
    EP_SESSION,
    EP_SESSION_TIMER,
    GITHUB_RELEASES_API,
    GITHUB_RELEASES_PAGE_URL,
    GITHUB_REPO_API,
    GITHUB_REPO_NAME,
    GITHUB_REPO_URL,
    HOTKEY_SITE_LABELS,
    HOTKEY_SITE_ORDER,
    PHASE_DISPLAY_MAP,
    PICK_SLOT_LABELS,
    PICK_SLOT_ORDER,
    PLATFORM_TO_REGION,
    PRACTICE_TOOL_GAME_MODE,
    PRESET_ENABLED_QUEUE_IDS,
    QUEUE_ID_LABELS,
    REGION_LIST,
    STATS_SITE_LABELS,
    STATS_SITE_ORDER,
    SUMMONER_SPELL_LIST,
    SUMMONER_SPELL_MAP,
    THEME_LABELS,
    THEME_ORDER,
    THEME_PALETTE,
    URL_CDRAGON_ASSET_PREFIX,
    URL_CDRAGON_CHAMPION_DETAIL,
    URL_DD_CHAMPION_DETAIL,
    URL_DD_CHAMPIONS,
    URL_DD_IMG_CHAMP,
    URL_DD_IMG_SPELL,
    URL_DD_SKIN_SPLASH,
    URL_DD_SUMMONERS,
    URL_DD_VERSIONS,
    URL_PERK_ICON_PREFIX,
    URL_PHASE_RUSH_ICON,
    WEBSITE_LOGO_FILES,
)
from .logging_config import LOG_FILE_PATH
from .paths import (
    DDRAGON_CACHE_FILE,
    HISTORY_PATH,
    ICONS_CACHE_DIR,
    LOCKFILE_PATH,
    PARAMETERS_PATH,
    RUNES_CACHE_DIR,
    SKINS_CACHE_DIR,
    SPELLS_CACHE_DIR,
    get_appdata_path,
    resource_path,
)
from .settings import DEFAULT_PARAMS, FIRST_LAUNCH_PARAMS, normalize_bool


def load_parameters():
    """Load application parameters from the TOML settings file."""
    return _settings.load_parameters()


def save_parameters(params):
    """Persist application parameters to the TOML settings file."""
    return _settings.save_parameters(params)


def export_parameters_to_file(path, params):
    """Export parameters to a chosen TOML or JSON file."""
    return _settings.export_parameters_to_file(path, params)


def import_parameters_from_file(path):
    """Import parameters from a chosen TOML or JSON file."""
    return _settings.import_parameters_from_file(path)


def get_cache_dirs():
    """Create cache directories if they do not exist."""
    return _settings.get_cache_dirs()


__all__ = [
    "APP_BUILD_NAME",
    "APP_IMAGE_FILES",
    "APP_NAME",
    "CONFIG_SCHEMA_VERSION",
    "CURRENT_VERSION",
    "DDRAGON_CACHE_FILE",
    "DEFAULT_PARAMS",
    "EP_CHAT_ME",
    "EP_CS_RUNE_PAGE",
    "EP_CURRENT_SUMMONER",
    "EP_GAMEFLOW",
    "EP_LOBBY",
    "EP_LOGIN",
    "EP_PERKS_CURRENT_PAGE",
    "EP_PERKS_INVENTORY",
    "EP_PERKS_PAGES",
    "EP_PERKS_STYLES",
    "EP_PICKABLE",
    "EP_READY_CHECK",
    "EP_SESSION",
    "EP_SESSION_TIMER",
    "FIRST_LAUNCH_PARAMS",
    "GITHUB_RELEASES_API",
    "GITHUB_RELEASES_PAGE_URL",
    "GITHUB_REPO_API",
    "GITHUB_REPO_NAME",
    "GITHUB_REPO_URL",
    "HISTORY_PATH",
    "HOTKEY_SITE_LABELS",
    "HOTKEY_SITE_ORDER",
    "ICONS_CACHE_DIR",
    "LOCKFILE_PATH",
    "LOG_FILE_PATH",
    "PARAMETERS_PATH",
    "PHASE_DISPLAY_MAP",
    "PICK_SLOT_LABELS",
    "PICK_SLOT_ORDER",
    "PLATFORM_TO_REGION",
    "PRACTICE_TOOL_GAME_MODE",
    "PRESET_ENABLED_QUEUE_IDS",
    "QUEUE_ID_LABELS",
    "REGION_LIST",
    "RUNES_CACHE_DIR",
    "SKINS_CACHE_DIR",
    "SPELLS_CACHE_DIR",
    "STATS_SITE_LABELS",
    "STATS_SITE_ORDER",
    "SUMMONER_SPELL_LIST",
    "SUMMONER_SPELL_MAP",
    "THEME_LABELS",
    "THEME_ORDER",
    "THEME_PALETTE",
    "URL_CDRAGON_ASSET_PREFIX",
    "URL_CDRAGON_CHAMPION_DETAIL",
    "URL_DD_CHAMPIONS",
    "URL_DD_CHAMPION_DETAIL",
    "URL_DD_IMG_CHAMP",
    "URL_DD_IMG_SPELL",
    "URL_DD_SKIN_SPLASH",
    "URL_DD_SUMMONERS",
    "URL_DD_VERSIONS",
    "URL_PERK_ICON_PREFIX",
    "URL_PHASE_RUSH_ICON",
    "WEBSITE_LOGO_FILES",
    "export_parameters_to_file",
    "get_appdata_path",
    "get_cache_dirs",
    "import_parameters_from_file",
    "load_parameters",
    "normalize_bool",
    "resource_path",
    "save_parameters",
]
