"""
FILE NAME: src/otp_lol/config/settings.py
GLOBAL PURPOSE:
- Define default configuration payloads for the application.
- Load, normalize, reset, import, and export persisted settings.
- Keep the current TOML schema explicit for pick slots and skin settings.

KEY FUNCTIONS:
- build_pick_slot_defaults: Build a normalized pick-slot structure.
- load_parameters: Load and validate the persisted settings file.
- save_parameters: Persist normalized settings to disk.
- _normalize_parameters: Enforce the current configuration schema.

AUDIENCE & LOGIC:
Why:
This module exists so settings schema rules, first-launch defaults, and persistence behavior remain centralized and predictable.
For whom:
Developers maintaining settings persistence, schema evolution, and configuration import or export.

DEPENDENCIES:
Used by:
- otp_lol.config.__init__ and runtime modules that load or save settings.
Uses:
- Standard library: copy, json, logging, os, shutil, typing
- Local modules: otp_lol.config.constants, otp_lol.config.paths
"""

import copy
import json
import logging
import os
import tempfile
import time
import tomllib
from typing import Any

import tomli_w

from .constants import (
    CONFIG_SCHEMA_VERSION,
    CURRENT_VERSION,
    PICK_SLOT_ORDER,
    REGION_LIST,
    SUMMONER_SPELL_MAP,
)
from .paths import (
    ICONS_CACHE_DIR,
    PARAMETERS_JSON_PATH,
    PARAMETERS_PATH,
    RUNES_CACHE_DIR,
    SKINS_CACHE_DIR,
    SPELLS_CACHE_DIR,
)


def build_pick_slot_defaults(*, spell_1: str = "", spell_2: str = "") -> dict[str, dict[str, Any]]:
    """Return a normalized pick-slot payload with optional default summoner spells."""
    return {
        slot: {
            "spell_1": spell_1,
            "spell_2": spell_2,
            "skin_mode": "none",
            "skin_id": 0,
            "skin_name": "",
            "skin_num": 0,
            "random_skin_id": 0,
            "random_skin_name": "",
            "random_skin_num": 0,
            "random_skin_pool": [],
            "rune_page_id": 0,
            "rune_page_name": "",
            "rune_auto_apply": True,
            "rune_keystone_path": "",
            "rune_sub_style_icon_path": "",
        }
        for slot in PICK_SLOT_ORDER
    }


def build_main_skin_mode_overrides(*, default_mode: str = "inherit") -> dict[str, str]:
    """Return main-window skin override defaults for each preset slot."""
    return {slot: default_mode for slot in PICK_SLOT_ORDER}


def build_demo_pick_slots() -> dict[str, dict[str, Any]]:
    """Return first-launch preset slots with visible spell and skin examples."""
    slots = build_pick_slot_defaults()
    slots["pick_1"].update(
        {
            "spell_1": "Flash",
            "spell_2": "Ignite",
            "skin_mode": "fixed",
            "skin_id": 86013,
            "skin_name": "God-King Garen",
            "skin_num": 13,
        }
    )
    slots["pick_2"].update(
        {
            "spell_1": "Flash",
            "spell_2": "Teleport",
            "skin_mode": "random",
            "random_skin_id": 99007,
            "random_skin_name": "Star Guardian Lux",
            "random_skin_num": 7,
            "random_skin_pool": [
                {"skin_id": 99007, "skin_name": "Star Guardian Lux", "skin_num": 7},
                {"skin_id": 99010, "skin_name": "Battle Academia Lux", "skin_num": 10},
            ],
        }
    )
    slots["pick_3"].update(
        {
            "spell_1": "Flash",
            "spell_2": "Barrier",
            "skin_mode": "fixed",
            "skin_id": 22004,
            "skin_name": "Queen Ashe",
            "skin_num": 4,
        }
    )
    return slots


DEFAULT_PARAMS: dict[str, Any] = {
    "config_version": CURRENT_VERSION,
    "config_schema_version": CONFIG_SCHEMA_VERSION,
    "auto_accept_enabled": True,
    "auto_pick_enabled": True,
    "auto_ban_enabled": True,
    "auto_summoners_enabled": True,
    "presets_enabled": True,
    "selected_pick_1": "Garen",
    "selected_pick_2": "Lux",
    "selected_pick_3": "Ashe",
    "selected_ban": "Teemo",
    "pick_slots": build_demo_pick_slots(),
    "theme": "darkly",
    "summoner_name_auto_detect": True,
    "manual_summoner_name": "VotrePseudo#VotreTag",
    "manual_region": "euw",
    "auto_detected_riot_id": "",
    "auto_detected_region": "",
    "auto_detected_platform": "",
    "preferred_stats_site": "opgg",
    "preferred_hotkey_site": "porofessor",
    "hotkey_toggle_window": "alt+c",
    "hotkey_open_site": "alt+p",
    "auto_play_again_enabled": False,
    "auto_hide_on_connect": True,
    "close_app_on_lol_exit": True,
    "ignored_update_version": "",
    "main_skin_mode_overrides": build_main_skin_mode_overrides(),
    "window_x": 0,
    "window_y": 0,
}

FIRST_LAUNCH_PARAMS: dict[str, Any] = copy.deepcopy(DEFAULT_PARAMS)
FIRST_LAUNCH_PARAMS.update(
    {
        "auto_accept_enabled": False,
        "auto_pick_enabled": False,
        "auto_ban_enabled": False,
        "auto_summoners_enabled": False,
        "presets_enabled": False,
        "auto_play_again_enabled": False,
    }
)


def _build_first_launch_payload() -> dict[str, Any]:
    """Return the fully normalized settings payload used for a true first launch."""
    return _normalize_parameters(copy.deepcopy(FIRST_LAUNCH_PARAMS))


def _atomic_write_bytes(path: str, content: bytes) -> None:
    """Replace a file atomically so an interrupted write keeps the previous file intact."""
    absolute_path = os.path.abspath(path)
    directory = os.path.dirname(absolute_path) or "."
    os.makedirs(directory, exist_ok=True)
    file_descriptor, temp_path = tempfile.mkstemp(
        prefix=f".{os.path.basename(absolute_path)}.",
        suffix=".tmp",
        dir=directory,
    )
    try:
        with os.fdopen(file_descriptor, "wb") as temporary_file:
            temporary_file.write(content)
            temporary_file.flush()
            os.fsync(temporary_file.fileno())
        os.replace(temp_path, absolute_path)
    finally:
        if os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except OSError:
                logging.debug("Unable to remove temporary settings file: %s", temp_path)


def _write_parameters_file(payload: dict[str, Any]) -> dict[str, Any]:
    """Normalize and write the settings payload to the main parameters file."""
    sanitized = _normalize_parameters(payload)
    content = tomli_w.dumps(sanitized).encode("utf-8")
    _atomic_write_bytes(PARAMETERS_PATH, content)
    return sanitized


def _migrate_json_to_toml() -> bool:
    """Migrate the legacy JSON settings file once, keeping a recoverable backup."""
    if os.path.exists(PARAMETERS_PATH) or not os.path.exists(PARAMETERS_JSON_PATH):
        return False
    try:
        with open(PARAMETERS_JSON_PATH, encoding="utf-8") as legacy_file:
            payload = json.load(legacy_file)
        _write_parameters_file(payload)
        backup_path = f"{PARAMETERS_JSON_PATH}.bak"
        os.replace(PARAMETERS_JSON_PATH, backup_path)
        logging.info("Migrated settings from %s to %s", PARAMETERS_JSON_PATH, PARAMETERS_PATH)
        return True
    except (OSError, TypeError, ValueError, json.JSONDecodeError) as e:
        logging.warning("Unable to migrate legacy JSON settings: %s", e)
        return False


def _reset_parameters_file(reason: str) -> dict[str, Any]:
    """Create first-launch settings for a missing or unrecoverable file."""
    logging.warning("Creating first-launch parameters.toml: %s", reason)
    return _write_parameters_file(_build_first_launch_payload())


def _backup_unreadable_file(path: str) -> None:
    """Move a broken settings file aside before creating a recoverable default."""
    if not os.path.exists(path):
        return
    backup_path = f"{path}.corrupt-{os.getpid()}-{time.time_ns()}.bak"
    try:
        os.replace(path, backup_path)
        logging.warning("Backed up unreadable settings file to %s", backup_path)
    except OSError as e:
        logging.warning("Unable to back up unreadable settings file %s: %s", path, e)


def load_parameters() -> dict[str, Any]:
    """Load, validate, and normalize parameters from the TOML settings file."""
    _migrate_json_to_toml()
    if not os.path.exists(PARAMETERS_PATH):
        return _reset_parameters_file("missing file")

    try:
        with open(PARAMETERS_PATH, "rb") as f:
            config = tomllib.load(f)
    except (tomllib.TOMLDecodeError, OSError) as e:
        logging.warning("Error loading settings: %s", e)
        _backup_unreadable_file(PARAMETERS_PATH)
        return _reset_parameters_file("invalid toml")

    if not isinstance(config, dict):
        _backup_unreadable_file(PARAMETERS_PATH)
        return _reset_parameters_file("root payload is not an object")

    try:
        schema_version = int(config.get("config_schema_version", CONFIG_SCHEMA_VERSION))
        if schema_version != CONFIG_SCHEMA_VERSION:
            raise ValueError(f"unsupported settings schema {schema_version}; expected {CONFIG_SCHEMA_VERSION}")
        normalized = _normalize_parameters(config)
    except (TypeError, ValueError, OverflowError) as e:
        logging.warning("Invalid settings payload: %s", e)
        _backup_unreadable_file(PARAMETERS_PATH)
        return _reset_parameters_file("unsupported or invalid settings payload")
    if config != normalized:
        try:
            _write_parameters_file(normalized)
        except OSError as e:
            logging.warning("Unable to persist normalized settings: %s", e)
    return normalized


def save_parameters(params: dict[str, Any]) -> bool:
    """Persist normalized parameters to the TOML settings file."""
    try:
        _write_parameters_file(params)
        return True
    except (OSError, TypeError, ValueError, OverflowError) as e:
        logging.error("Error saving settings: %s", e)
        return False


def export_parameters_to_file(path: str, params: dict[str, Any]) -> bool:
    """Export sanitized parameters to a chosen TOML or JSON file (detected from extension)."""
    try:
        sanitized = _normalize_parameters(params)
        if path.lower().endswith(".json"):
            content = json.dumps(sanitized, indent=4, ensure_ascii=False).encode("utf-8")
        else:
            content = tomli_w.dumps(sanitized).encode("utf-8")
        _atomic_write_bytes(path, content)
        return True
    except (OSError, TypeError, ValueError, OverflowError) as e:
        logging.error("Error exporting settings: %s", e)
        return False


def import_parameters_from_file(path: str) -> dict[str, Any]:
    """Import parameters from a TOML or JSON file and normalize them to the current schema."""
    if path.lower().endswith(".json"):
        with open(path, encoding="utf-8") as f:
            payload = json.load(f)
    else:
        with open(path, "rb") as f:
            payload = tomllib.load(f)
    if not isinstance(payload, dict):
        raise ValueError("The configuration file is invalid.")
    return _normalize_parameters(payload)


def _normalize_spell_value(value: Any) -> str:
    """Normalize legacy spell labels while preserving valid Riot spell names."""
    spell_name = str(value or "")
    if spell_name == "(Aucun)":
        return "(None)"
    return spell_name if spell_name in SUMMONER_SPELL_MAP else ""


def normalize_bool(value: Any, *, default: bool) -> bool:
    """Normalize TOML/JSON boolean values without treating arbitrary strings as true."""
    if isinstance(value, bool):
        return value
    if isinstance(value, int) and value in {0, 1}:
        return bool(value)
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"true", "1", "yes", "y", "on", "oui"}:
            return True
        if normalized in {"false", "0", "no", "n", "off", "non"}:
            return False
    return default


def _normalize_non_negative_int(value: Any, *, default: int = 0) -> int:
    """Convert a persisted identifier to a non-negative integer safely."""
    try:
        normalized = int(value)
    except (TypeError, ValueError, OverflowError):
        return default
    return normalized if normalized >= 0 else default


def _normalize_int(value: Any, *, default: int = 0) -> int:
    """Convert a persisted integer-like value safely, allowing negative coordinates."""
    try:
        return int(value)
    except (TypeError, ValueError, OverflowError):
        return default


def _normalize_text(value: Any, *, lower: bool = False) -> str:
    """Normalize persisted text fields before runtime consumers use string methods."""
    normalized = str(value or "").strip()
    return normalized.lower() if lower else normalized


def _normalize_skin_mode(value: Any) -> str:
    """Normalize stored skin modes to the supported values."""
    mode = str(value or "none").strip().lower()
    return mode if mode in {"none", "fixed", "random"} else "none"


def _normalize_skin_override_mode(value: Any) -> str:
    """Normalize the main-window skin override value to a supported mode."""
    mode = str(value or "inherit").strip().lower()
    return mode if mode in {"inherit", "none", "fixed", "random"} else "inherit"


def _normalize_skin_override_modes(value: Any) -> dict[str, str]:
    """Build the current per-slot main-window skin override mapping."""
    normalized = build_main_skin_mode_overrides()
    if isinstance(value, dict):
        for slot in PICK_SLOT_ORDER:
            normalized[slot] = _normalize_skin_override_mode(value.get(slot, normalized[slot]))
    return normalized


def _normalize_skin_id(value: Any) -> int:
    """Convert persisted skin identifiers to a safe non-negative integer."""
    try:
        skin_id = int(value or 0)
    except (TypeError, ValueError, OverflowError):
        return 0
    return skin_id if skin_id >= 0 else 0


def _normalize_skin_pool(value: Any) -> list[dict[str, Any]]:
    """Normalize and deduplicate a persisted random-skin pool."""
    if not isinstance(value, list):
        return []
    normalized_pool: list[dict[str, Any]] = []
    seen_ids: set[int] = set()
    for item in value:
        if not isinstance(item, dict):
            continue
        skin_id = _normalize_skin_id(item.get("skin_id", item.get("id", item.get("skinId", 0))))
        if skin_id <= 0 or skin_id in seen_ids:
            continue
        seen_ids.add(skin_id)
        normalized_pool.append(
            {
                "skin_id": skin_id,
                "skin_name": str(item.get("skin_name", item.get("name", "")) or ""),
                "skin_num": _normalize_skin_id(item.get("skin_num", item.get("num", 0))),
            }
        )
    return normalized_pool


def _build_normalized_pick_slots(
    raw_slots: Any,
    *,
    fallback_spell_1: Any = "",
    fallback_spell_2: Any = "",
) -> dict[str, dict[str, Any]]:
    """Normalize the current per-slot pick configuration."""
    slots = build_pick_slot_defaults(
        spell_1=_normalize_spell_value(fallback_spell_1),
        spell_2=_normalize_spell_value(fallback_spell_2),
    )

    if not isinstance(raw_slots, dict):
        return slots

    for slot in PICK_SLOT_ORDER:
        slot_data = raw_slots.get(slot, {})
        if not isinstance(slot_data, dict):
            slot_data = {}
        slots[slot].update(
            {
                "spell_1": _normalize_spell_value(slot_data.get("spell_1", slots[slot]["spell_1"])),
                "spell_2": _normalize_spell_value(slot_data.get("spell_2", slots[slot]["spell_2"])),
                "skin_mode": _normalize_skin_mode(slot_data.get("skin_mode", slots[slot]["skin_mode"])),
                "skin_id": _normalize_skin_id(slot_data.get("skin_id", slots[slot]["skin_id"])),
                "skin_name": str(slot_data.get("skin_name", slots[slot]["skin_name"]) or ""),
                "skin_num": _normalize_skin_id(slot_data.get("skin_num", slots[slot]["skin_num"])),
                "random_skin_id": _normalize_skin_id(slot_data.get("random_skin_id", slots[slot]["random_skin_id"])),
                "random_skin_name": str(slot_data.get("random_skin_name", slots[slot]["random_skin_name"]) or ""),
                "random_skin_num": _normalize_skin_id(slot_data.get("random_skin_num", slots[slot]["random_skin_num"])),
                "random_skin_pool": _normalize_skin_pool(
                    slot_data.get("random_skin_pool", slots[slot]["random_skin_pool"])
                ),
                "rune_page_id": _normalize_non_negative_int(slot_data.get("rune_page_id", slots[slot]["rune_page_id"])),
                "rune_page_name": str(slot_data.get("rune_page_name", slots[slot]["rune_page_name"]) or ""),
                "rune_auto_apply": normalize_bool(
                    slot_data.get("rune_auto_apply", slots[slot]["rune_auto_apply"]),
                    default=slots[slot]["rune_auto_apply"],
                ),
                "rune_keystone_path": str(slot_data.get("rune_keystone_path", slots[slot]["rune_keystone_path"]) or ""),
                "rune_sub_style_icon_path": str(
                    slot_data.get("rune_sub_style_icon_path", slots[slot]["rune_sub_style_icon_path"]) or ""
                ),
            }
        )
    return slots


def _normalize_parameters(config: dict[str, Any]) -> dict[str, Any]:
    """Normalize the current TOML settings schema and discard unknown keys."""
    if not isinstance(config, dict):
        config = {}
    merged = copy.deepcopy(DEFAULT_PARAMS)
    merged["config_version"] = CURRENT_VERSION
    merged["config_schema_version"] = CONFIG_SCHEMA_VERSION
    for key, value in config.items():
        if key == "pick_slots" or key not in DEFAULT_PARAMS:
            continue
        merged[key] = value

    if "auto_detected_region" not in config and config.get("summoner_name_auto_detect"):
        merged["auto_detected_region"] = ""

    if "auto_detected_riot_id" not in config:
        merged["auto_detected_riot_id"] = ""

    if "auto_detected_platform" not in config:
        merged["auto_detected_platform"] = ""

    merged["selected_pick_1"] = str(config.get("selected_pick_1", DEFAULT_PARAMS["selected_pick_1"]))
    merged["selected_pick_2"] = str(config.get("selected_pick_2", DEFAULT_PARAMS["selected_pick_2"]))
    merged["selected_pick_3"] = str(config.get("selected_pick_3", DEFAULT_PARAMS["selected_pick_3"]))
    merged["selected_ban"] = str(config.get("selected_ban", DEFAULT_PARAMS["selected_ban"]))
    merged["manual_summoner_name"] = _normalize_text(
        config.get("manual_summoner_name", DEFAULT_PARAMS["manual_summoner_name"]),
    )
    merged["auto_detected_riot_id"] = _normalize_text(config.get("auto_detected_riot_id"))
    merged["auto_detected_region"] = _normalize_text(config.get("auto_detected_region"), lower=True)
    merged["auto_detected_platform"] = _normalize_text(config.get("auto_detected_platform"), lower=True)
    merged["window_x"] = _normalize_int(config.get("window_x", DEFAULT_PARAMS["window_x"]))
    merged["window_y"] = _normalize_int(config.get("window_y", DEFAULT_PARAMS["window_y"]))
    boolean_keys = {
        "auto_accept_enabled",
        "auto_pick_enabled",
        "auto_ban_enabled",
        "auto_summoners_enabled",
        "presets_enabled",
        "summoner_name_auto_detect",
        "auto_play_again_enabled",
        "auto_hide_on_connect",
        "close_app_on_lol_exit",
    }
    for key in boolean_keys:
        merged[key] = normalize_bool(config.get(key, DEFAULT_PARAMS[key]), default=DEFAULT_PARAMS[key])

    manual_region = str(config.get("manual_region", DEFAULT_PARAMS["manual_region"])).strip().lower()
    merged["manual_region"] = manual_region if manual_region in REGION_LIST else DEFAULT_PARAMS["manual_region"]
    merged["main_skin_mode_overrides"] = _normalize_skin_override_modes(config.get("main_skin_mode_overrides"))
    merged["pick_slots"] = _build_normalized_pick_slots(
        config.get("pick_slots"),
        fallback_spell_1=config.get("global_spell_1", DEFAULT_PARAMS["pick_slots"]["pick_1"]["spell_1"]),
        fallback_spell_2=config.get("global_spell_2", DEFAULT_PARAMS["pick_slots"]["pick_1"]["spell_2"]),
    )

    preferred_stats_site = (
        str(config.get("preferred_stats_site", DEFAULT_PARAMS["preferred_stats_site"])).lower().strip()
    )
    if preferred_stats_site not in {"opgg", "deeplol", "dpm", "leagueofgraphs"}:
        preferred_stats_site = DEFAULT_PARAMS["preferred_stats_site"]
    merged["preferred_stats_site"] = preferred_stats_site

    preferred_hotkey_site = (
        str(config.get("preferred_hotkey_site", DEFAULT_PARAMS["preferred_hotkey_site"])).lower().strip()
    )
    if preferred_hotkey_site not in {"porofessor", "deeplol", "dpm", "opgg"}:
        preferred_hotkey_site = DEFAULT_PARAMS["preferred_hotkey_site"]
    merged["preferred_hotkey_site"] = preferred_hotkey_site

    hotkey_toggle_window = (
        str(config.get("hotkey_toggle_window", DEFAULT_PARAMS["hotkey_toggle_window"])).strip().lower()
    )
    hotkey_open_site = str(config.get("hotkey_open_site", DEFAULT_PARAMS["hotkey_open_site"])).strip().lower()
    merged["hotkey_toggle_window"] = hotkey_toggle_window or DEFAULT_PARAMS["hotkey_toggle_window"]
    merged["hotkey_open_site"] = hotkey_open_site or DEFAULT_PARAMS["hotkey_open_site"]
    merged["ignored_update_version"] = str(
        config.get("ignored_update_version", DEFAULT_PARAMS["ignored_update_version"])
    ).strip()

    theme = str(config.get("theme", DEFAULT_PARAMS["theme"])).strip().lower()
    if theme not in {"darkly", "flatly"}:
        theme = DEFAULT_PARAMS["theme"]
    merged["theme"] = theme

    return {key: copy.deepcopy(merged[key]) for key in DEFAULT_PARAMS}


def get_cache_dirs() -> None:
    """Create cache directories if they do not exist."""
    for cache_dir in [ICONS_CACHE_DIR, SPELLS_CACHE_DIR, SKINS_CACHE_DIR, RUNES_CACHE_DIR]:
        if os.path.exists(cache_dir) and not os.path.isdir(cache_dir):
            raise OSError(f"Cache path is not a directory: {cache_dir}")
        os.makedirs(cache_dir, exist_ok=True)
