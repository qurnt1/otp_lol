"""
FILE NAME: src/otp_lol/core/datadragon.py
GLOBAL PURPOSE:
- Fetch, cache, and resolve champion and summoner metadata from Riot sources.
- Provide image-loading helpers for champion icons, spells, and skin previews.
- Offer resilient fallback behavior when network access or cache data is unavailable.

KEY FUNCTIONS:
- DataDragon: Own champion metadata, image caches, and lookup helpers.
- load: Populate champion metadata from Data Dragon, cache, or local fallback data.
- resolve_champion: Convert a champion name or identifier into a champion id.
- get_remote_image: Fetch and cache remote images used by the UI.

AUDIENCE & LOGIC:
Why:
This module exists so metadata retrieval, caching, and image access stay consistent across automation and UI code.
For whom:
Developers maintaining champion metadata, image caches, and Riot data integration.

DEPENDENCIES:
Used by:
- otp_lol.application, otp_lol.core.websocket, and multiple UI modules.
Uses:
- Standard library: io, json, logging, os, re, threading, typing, unicodedata
- Third-party libraries: Pillow, requests
- Local modules: otp_lol.config
"""

import hashlib
import json
import logging
import os
import re
import tempfile
import unicodedata
from collections import OrderedDict
from contextlib import suppress
from io import BytesIO
from threading import Lock
from typing import Any

import requests
from PIL import Image, ImageDraw

from ..config import (
    DDRAGON_CACHE_FILE,
    ICONS_CACHE_DIR,
    SKINS_CACHE_DIR,
    SPELLS_CACHE_DIR,
    URL_CDRAGON_ASSET_PREFIX,
    URL_CDRAGON_CHAMPION_DETAIL,
    URL_DD_CHAMPION_DETAIL,
    URL_DD_CHAMPIONS,
    URL_DD_IMG_CHAMP,
    URL_DD_IMG_SPELL,
    URL_DD_SKIN_SPLASH,
    URL_DD_SUMMONERS,
    URL_DD_VERSIONS,
    URL_PERK_ICON_PREFIX,
    get_cache_dirs,
)


class DataDragon:
    """Manage Riot metadata lookups, local caches, and image retrieval helpers."""

    def __init__(self):
        """Initialize metadata containers and in-memory image caches."""
        self.loaded: bool = False
        self.version: str | None = None
        self.by_norm_name: dict[str, int] = {}
        self.by_id: dict[int, dict[str, Any]] = {}
        self.name_by_id: dict[int, str] = {}
        self.all_names: list[str] = []
        self.summoner_data: dict[str, str] = {}
        self.summoner_loaded: bool = False
        self._image_cache: OrderedDict[str, Image.Image] = OrderedDict()
        self._image_cache_maxsize: int = 200
        self._champion_detail_cache: dict[int, dict[str, Any]] = {}
        self._cdragon_champion_detail_cache: dict[int, dict[str, Any]] = {}
        self._rune_perk_icon_path_by_id: dict[int, str] | None = None
        self._rune_perk_name_by_id: dict[int, str] | None = None
        self._cache_lock = Lock()
        self._load_lock = Lock()
        self._summoner_lock = Lock()
        self._rune_index_lock = Lock()

    def _cache_get(self, key: str) -> Image.Image | None:
        with self._cache_lock:
            if key in self._image_cache:
                self._image_cache.move_to_end(key)
                return self._image_cache[key].copy()
        return None

    def _cache_put(self, key: str, image: Image.Image) -> None:
        with self._cache_lock:
            if key in self._image_cache:
                self._image_cache.move_to_end(key)
            self._image_cache[key] = image
            while len(self._image_cache) > self._image_cache_maxsize:
                self._image_cache.popitem(last=False)

    def _cache_file_version_path(self, cache_path: str) -> str:
        return f"{cache_path}.version"

    @staticmethod
    def _atomic_write_bytes(path: str, content: bytes) -> None:
        """Publish a cache file in one rename so interrupted downloads stay unreadable, not partial."""
        absolute_path = os.path.abspath(path)
        directory = os.path.dirname(absolute_path) or "."
        os.makedirs(directory, exist_ok=True)
        file_descriptor, temp_path = tempfile.mkstemp(
            prefix=f".{os.path.basename(absolute_path)}.", suffix=".tmp", dir=directory
        )
        try:
            with os.fdopen(file_descriptor, "wb") as temporary_file:
                temporary_file.write(content)
                temporary_file.flush()
                os.fsync(temporary_file.fileno())
            os.replace(temp_path, absolute_path)
        finally:
            if os.path.exists(temp_path):
                try:
                    os.remove(temp_path)
                except OSError:
                    logging.debug("Unable to remove temporary cache file: %s", temp_path)

    def _is_cache_file_fresh(self, cache_path: str) -> bool:
        if not self.version or not os.path.exists(cache_path):
            return False
        try:
            with open(self._cache_file_version_path(cache_path), encoding="utf-8") as version_file:
                return version_file.read().strip() == self.version
        except OSError:
            return False

    def _mark_cache_file_fresh(self, cache_path: str) -> None:
        if not self.version:
            return
        with suppress(Exception):
            self._atomic_write_bytes(
                self._cache_file_version_path(cache_path),
                self.version.encode("utf-8"),
            )

    @staticmethod
    def _normalize(s: str) -> str:
        """Normalize champion names so user-friendly aliases map to stable lookup keys."""
        s = s.strip().lower()
        s = unicodedata.normalize("NFD", s)
        s = "".join(c for c in s if unicodedata.category(c) != "Mn")
        s = re.sub(r"[^a-z0-9]+", "", s)
        return s

    def _load_from_cache(self, target_version: str | None = None) -> bool:
        """Load cached champion metadata when the cache matches the requested version."""
        try:
            if os.path.exists(DDRAGON_CACHE_FILE):
                with open(DDRAGON_CACHE_FILE, encoding="utf-8") as f:
                    payload = json.load(f)
                if not isinstance(payload, dict):
                    return False
                cached_version = payload.get("version")
                if target_version and cached_version != target_version:
                    return False
                raw_by_norm_name = payload.get("by_norm_name")
                raw_by_id = payload.get("by_id")
                raw_name_by_id = payload.get("name_by_id")
                if not all(isinstance(value, dict) for value in (raw_by_norm_name, raw_by_id, raw_name_by_id)):
                    return False
                by_norm_name = {str(key): int(value) for key, value in raw_by_norm_name.items()}
                by_id = {}
                for key, value in raw_by_id.items():
                    if not isinstance(value, dict):
                        return False
                    by_id[int(key)] = value
                name_by_id = {int(key): str(value) for key, value in raw_name_by_id.items()}
                self.version = cached_version
                self.by_norm_name = by_norm_name
                self.by_id = by_id
                self.name_by_id = name_by_id
                self.all_names = sorted(list(self.name_by_id.values()))
                self.loaded = True
                return True
        except Exception as e:
            logging.warning("DataDragon: Cache error - %s", e)
        return False

    def _save_cache(self) -> None:
        """Persist the current champion metadata cache to disk."""
        try:
            content = json.dumps(
                {
                    "version": self.version,
                    "by_norm_name": self.by_norm_name,
                    "by_id": self.by_id,
                    "name_by_id": self.name_by_id,
                }
            ).encode("utf-8")
            self._atomic_write_bytes(DDRAGON_CACHE_FILE, content)
        except Exception as e:
            logging.warning("DataDragon: Cache save error - %s", e)

    def load(self) -> None:
        """Load champion metadata once, even when startup callers race."""
        if self.loaded:
            return
        with self._load_lock:
            if self.loaded:
                return
            self._load_unlocked()

    def _load_unlocked(self) -> None:
        """Load champion metadata, preferring fresh Data Dragon data, then cache, then fallback."""
        # Cache directories are prepared up front because both metadata and image
        # fetches rely on them later in the session.
        get_cache_dirs()
        online_version = self._fetch_latest_version()
        if self._load_from_cache(target_version=online_version):
            logging.info("DataDragon: Loaded from cache (version %s)", self.version)
            return

        if not online_version:
            logging.warning("DataDragon: No online version and invalid cache, using fallback data")
            self._load_fallback_data()
            return

        try:
            url_champs = URL_DD_CHAMPIONS.format(version=online_version)
            response = requests.get(url_champs, timeout=10)
            response.raise_for_status()
            champions_data = response.json().get("data", {})

            self.by_id = {}
            self.name_by_id = {}
            self.by_norm_name = {}

            for champ_slug, info in champions_data.items():
                champ_name = info.get("name") or champ_slug
                champion_id = int(info.get("key"))
                self.by_id[champion_id] = info
                self.name_by_id[champion_id] = champ_name
                self.by_norm_name[self._normalize(champ_name)] = champion_id
                self.by_norm_name[self._normalize(info.get("id", champ_slug))] = champion_id

            self._add_champion_aliases()
            self.version = online_version
            self.all_names = sorted(list(self.name_by_id.values()))
            self.loaded = True
            self._save_cache()
            logging.info("DataDragon: Loaded from API (version %s, %s champions)", online_version, len(self.all_names))
        except requests.RequestException as e:
            logging.error("DataDragon: Network error while loading - %s", e)
            self._load_fallback_data()
        except Exception as e:
            logging.error("DataDragon: Unexpected error - %s", e)
            self._load_fallback_data()

    def _fetch_latest_version(self) -> str | None:
        """Return the latest online Data Dragon version when the network is reachable."""
        try:
            response = requests.get(URL_DD_VERSIONS, timeout=5)
            response.raise_for_status()
            versions = response.json()
            if versions:
                return versions[0]
        except requests.RequestException as e:
            logging.warning("DataDragon: Unable to fetch online version - %s", e)
        except Exception as e:
            logging.warning("DataDragon: Version parsing error - %s", e)
        return None

    def _add_champion_aliases(self) -> None:
        """Register manual aliases for champions whose public names differ from internal slugs."""
        aliases = {
            "wukong": "monkeyking",
            "renata": "renataglasc",
        }
        for alias_name, internal_name in aliases.items():
            norm_alias = self._normalize(alias_name)
            norm_internal = self._normalize(internal_name)
            if norm_internal in self.by_norm_name:
                self.by_norm_name[norm_alias] = self.by_norm_name[norm_internal]

    def _load_fallback_data(self) -> None:
        """Load a minimal offline champion list when full metadata cannot be fetched."""
        logging.info("DataDragon: Loading fallback data")
        basic_champions = {
            "Garen": 86,
            "Teemo": 17,
            "Ashe": 22,
            "Lux": 99,
            "Jinx": 222,
            "Ahri": 103,
        }
        for name, champion_id in basic_champions.items():
            norm_name = self._normalize(name)
            self.by_norm_name[norm_name] = champion_id
            self.by_id[champion_id] = {"name": name, "key": str(champion_id)}
            self.name_by_id[champion_id] = name

        self.version = "offline"
        self.all_names = sorted(list(self.name_by_id.values()))
        self.loaded = True

    def resolve_champion(self, name_or_id: Any) -> int | None:
        """Resolve a champion name or identifier to a numeric champion id."""
        self.load()
        if name_or_id is None:
            return None
        try:
            return int(name_or_id)
        except (ValueError, TypeError):
            pass
        normalized_name = self._normalize(str(name_or_id))
        return self.by_norm_name.get(normalized_name)

    def id_to_name(self, champion_id: int) -> str | None:
        """Return the public champion name for a numeric champion id."""
        self.load()
        return self.name_by_id.get(champion_id)

    def get_champion_tags(self, name_or_id: Any) -> list[str]:
        """Return champion role tags from the loaded champion metadata."""
        champion_id = self.resolve_champion(name_or_id)
        if not champion_id:
            return []
        champ_data = self.by_id.get(champion_id) or {}
        tags = champ_data.get("tags", [])
        return [str(tag) for tag in tags if str(tag).strip()]

    def get_champion_icon(self, name_or_id: Any) -> Image.Image | None:
        champion_id = self.resolve_champion(name_or_id)
        if not champion_id:
            return None

        cache_key = f"champ_{champion_id}"
        cached = self._cache_get(cache_key)
        if cached:
            return cached

        champ_data = self.by_id.get(champion_id)
        if not champ_data:
            return None

        image_filename = champ_data.get("image", {}).get("full")
        if not image_filename:
            return None

        local_path = os.path.join(ICONS_CACHE_DIR, image_filename)
        if self._is_cache_file_fresh(local_path):
            try:
                with Image.open(local_path) as source:
                    img = source.convert("RGBA").copy()
                self._cache_put(cache_key, img)
                return img
            except Exception as e:
                logging.debug("Icon cache read error for %s: %s", image_filename, e)

        url = URL_DD_IMG_CHAMP.format(version=self.version, filename=image_filename)
        try:
            response = requests.get(url, timeout=5)
            if response.status_code == 200:
                with Image.open(BytesIO(response.content)) as source:
                    img = source.convert("RGBA").copy()
                os.makedirs(ICONS_CACHE_DIR, exist_ok=True)
                self._atomic_write_bytes(local_path, response.content)
                self._cache_put(cache_key, img)
                self._mark_cache_file_fresh(local_path)
                return img
        except Exception as e:
            logging.warning("DataDragon: Champion icon download error - %s", e)
        return None

    def load_summoners(self) -> None:
        with self._summoner_lock:
            if self.summoner_loaded:
                return
            if not self.version:
                self.load()

            url = URL_DD_SUMMONERS.format(version=self.version)
            try:
                response = requests.get(url, timeout=5)
                if response.status_code == 200:
                    data = response.json().get("data", {})
                    for _, info in data.items():
                        name = info.get("name")
                        image_full = info.get("image", {}).get("full")
                        if name and image_full:
                            self.summoner_data[name] = image_full
                    self.summoner_loaded = True
            except Exception as e:
                logging.warning("DataDragon: Summoner data loading error - %s", e)

    def get_summoner_icon(self, spell_name: str) -> Image.Image | None:
        if spell_name in {"(None)", "(Aucun)"} or not spell_name:
            return None

        cache_key = f"spell_{spell_name}"
        cached = self._cache_get(cache_key)
        if cached:
            return cached

        self.load_summoners()
        image_filename = self.summoner_data.get(spell_name)
        if not image_filename:
            return None

        local_path = os.path.join(SPELLS_CACHE_DIR, image_filename)
        if self._is_cache_file_fresh(local_path):
            try:
                with Image.open(local_path) as source:
                    img = source.convert("RGBA").copy()
                self._cache_put(cache_key, img)
                return img
            except Exception as e:
                logging.debug("Summ icon cache read error for %s: %s", image_filename, e)

        url = URL_DD_IMG_SPELL.format(version=self.version, filename=image_filename)
        try:
            response = requests.get(url, timeout=5)
            if response.status_code == 200:
                with Image.open(BytesIO(response.content)) as source:
                    img = source.convert("RGBA").copy()
                os.makedirs(SPELLS_CACHE_DIR, exist_ok=True)
                self._atomic_write_bytes(local_path, response.content)
                self._cache_put(cache_key, img)
                self._mark_cache_file_fresh(local_path)
                return img
        except Exception as e:
            logging.warning("DataDragon: Summ icon download error - %s", e)
        return None

    def get_champion_detail(self, name_or_id: Any) -> dict[str, Any] | None:
        champion_id = self.resolve_champion(name_or_id)
        if not champion_id:
            return None

        with self._cache_lock:
            cached = self._champion_detail_cache.get(champion_id)
            if cached:
                return dict(cached)

        if not self.version:
            self.load()

        champ_data = self.by_id.get(champion_id) or {}
        champion_slug = champ_data.get("id")
        if not champion_slug or not self.version:
            return None

        try:
            url = URL_DD_CHAMPION_DETAIL.format(version=self.version, champion=champion_slug)
            response = requests.get(url, timeout=8)
            response.raise_for_status()
            payload = response.json().get("data", {})
            detail = payload.get(champion_slug)
            if isinstance(detail, dict):
                with self._cache_lock:
                    self._champion_detail_cache[champion_id] = detail
                return dict(detail)
        except requests.RequestException as e:
            logging.warning("DataDragon: Champion detail download error - %s", e)
        except Exception as e:
            logging.warning("DataDragon: Champion detail parsing error - %s", e)
        return None

    @staticmethod
    def cdragon_url_from_asset_path(asset_path: str) -> str | None:
        raw_path = str(asset_path or "").strip()
        if not raw_path:
            return None
        normalized = raw_path.replace("\\", "/")
        prefix = "/lol-game-data/assets/"
        lowered = normalized.lower()
        relative = lowered[len(prefix) :] if lowered.startswith(prefix) else lowered.lstrip("/")
        if not relative.startswith("assets/"):
            return None
        return f"{URL_CDRAGON_ASSET_PREFIX}{relative}"

    def get_cdragon_champion_detail(self, name_or_id: Any) -> dict[str, Any] | None:
        champion_id = self.resolve_champion(name_or_id)
        if not champion_id:
            return None

        with self._cache_lock:
            cached = self._cdragon_champion_detail_cache.get(champion_id)
            if cached:
                return dict(cached)

        try:
            url = URL_CDRAGON_CHAMPION_DETAIL.format(champion_id=champion_id)
            response = requests.get(url, timeout=8)
            response.raise_for_status()
            detail = response.json()
            if isinstance(detail, dict):
                with self._cache_lock:
                    self._cdragon_champion_detail_cache[champion_id] = detail
                return dict(detail)
        except requests.RequestException as e:
            logging.warning("DataDragon: CDragon champion detail download error - %s", e)
        except Exception as e:
            logging.warning("DataDragon: CDragon champion detail parsing error - %s", e)
        return None

    def get_skin_catalog(self, name_or_id: Any) -> list[dict[str, Any]]:
        champion_id = self.resolve_champion(name_or_id)
        if not champion_id:
            return []

        detail = self.get_champion_detail(champion_id)
        if not detail:
            return []
        cdragon_detail = self.get_cdragon_champion_detail(champion_id) or {}

        champion_slug = detail.get("id") or self.by_id.get(champion_id, {}).get("id")
        champion_name = detail.get("name") or self.id_to_name(champion_id) or str(name_or_id)
        skins = detail.get("skins", [])
        cdragon_skins = cdragon_detail.get("skins", []) if isinstance(cdragon_detail, dict) else []
        cdragon_by_skin_id: dict[int, dict[str, Any]] = {}
        cdragon_by_num: dict[int, dict[str, Any]] = {}
        cdragon_by_name: dict[str, dict[str, Any]] = {}
        for item in cdragon_skins if isinstance(cdragon_skins, list) else []:
            if not isinstance(item, dict):
                continue
            try:
                cdragon_skin_id = int(item.get("id") or item.get("skinId") or 0)
            except (TypeError, ValueError):
                cdragon_skin_id = 0
            try:
                cdragon_skin_num = int(item.get("num") or 0)
            except (TypeError, ValueError):
                cdragon_skin_num = 0
            if cdragon_skin_id:
                cdragon_by_skin_id[cdragon_skin_id] = item
            if cdragon_skin_num >= 0:
                cdragon_by_num[cdragon_skin_num] = item
            normalized_name = self._normalize(str(item.get("name") or ""))
            if normalized_name:
                cdragon_by_name[normalized_name] = item
        catalog: list[dict[str, Any]] = []
        for skin in skins:
            if skin.get("parentSkin") not in {None, "", 0}:
                continue
            try:
                skin_id = int(skin.get("id") or 0)
            except (TypeError, ValueError):
                skin_id = 0
            try:
                skin_num = int(skin.get("num") or 0)
            except (TypeError, ValueError):
                skin_num = 0
            name = str(skin.get("name") or "")
            cdragon_skin = (
                cdragon_by_skin_id.get(skin_id)
                or cdragon_by_num.get(skin_num)
                or cdragon_by_name.get(self._normalize(name))
                or {}
            )
            entry = {
                "champion_id": champion_id,
                "champion_name": champion_name,
                "champion_slug": champion_slug,
                "skin_id": skin_id,
                "skin_num": skin_num,
                "skin_name": name,
                "splash_url": URL_DD_SKIN_SPLASH.format(champion=champion_slug, skin_num=skin_num),
                "tile_url": self.cdragon_url_from_asset_path(cdragon_skin.get("tilePath", "")),
                "centered_splash_url": self.cdragon_url_from_asset_path(cdragon_skin.get("splashPath", "")),
                "uncentered_splash_url": self.cdragon_url_from_asset_path(cdragon_skin.get("uncenteredSplashPath", "")),
            }
            catalog.append(entry)
        return catalog

    def resolve_skin_data(
        self,
        name_or_id: Any,
        *,
        skin_name: str | None = None,
        skin_id: Any | None = None,
        skin_num: Any | None = None,
    ) -> dict[str, Any] | None:
        catalog = self.get_skin_catalog(name_or_id)
        if not catalog:
            return None

        if skin_id not in {None, ""}:
            try:
                target_skin_id = int(skin_id)
            except (TypeError, ValueError):
                target_skin_id = 0
            if target_skin_id:
                for entry in catalog:
                    if entry["skin_id"] == target_skin_id:
                        return dict(entry)

        if skin_num not in {None, ""}:
            try:
                target_skin_num = int(skin_num)
            except (TypeError, ValueError):
                target_skin_num = 0
            if target_skin_num >= 0:
                for entry in catalog:
                    if entry["skin_num"] == target_skin_num:
                        return dict(entry)

        normalized_name = self._normalize(str(skin_name or ""))
        if normalized_name:
            for entry in catalog:
                if self._normalize(entry["skin_name"]) == normalized_name:
                    return dict(entry)
        return None

    def get_skin_preview_url(
        self,
        champion_name_or_id: Any,
        *,
        skin_name: str | None = None,
        skin_id: Any | None = None,
        skin_num: Any | None = None,
    ) -> str | None:
        skin_data = self.resolve_skin_data(
            champion_name_or_id,
            skin_name=skin_name,
            skin_id=skin_id,
            skin_num=skin_num,
        )
        if not skin_data:
            return None
        return (
            skin_data.get("tile_url")
            or skin_data.get("centered_splash_url")
            or skin_data.get("uncentered_splash_url")
            or skin_data.get("splash_url")
        )

    @staticmethod
    def _communitydragon_asset_url(asset_path: str) -> str | None:
        normalized_path = str(asset_path or "").strip().replace("\\", "/")
        if not normalized_path:
            return None
        if normalized_path.startswith(("http://", "https://")):
            return normalized_path
        normalized_path = normalized_path.lstrip("/")
        lcu_prefix = "lol-game-data/assets/"
        if normalized_path.startswith(lcu_prefix):
            normalized_path = normalized_path[len(lcu_prefix) :]
        normalized_path = normalized_path.lower().lstrip("/")
        if not normalized_path:
            return None
        return f"{URL_PERK_ICON_PREFIX}/{normalized_path}"

    def _get_communitydragon_image(self, asset_path: str, *, cache_prefix: str) -> Image.Image | None:
        url = self._communitydragon_asset_url(asset_path)
        if not url:
            return None
        cache_key = f"{cache_prefix}_{hashlib.sha256(url.encode('utf-8')).hexdigest()[:16]}"
        cached = self._cache_get(cache_key)
        if cached:
            return cached

        try:
            response = requests.get(url, timeout=8)
            if response.status_code == 200:
                with Image.open(BytesIO(response.content)) as source:
                    img = source.convert("RGBA").copy()
                self._cache_put(cache_key, img)
                return img
        except Exception as e:
            logging.warning("DataDragon: CommunityDragon rune icon download error for %s: %s", url, e)
        return None

    def get_rune_perk_icon(self, perk_icon_path: str) -> Image.Image | None:
        """Download a rune perk icon from CommunityDragon."""
        return self._get_communitydragon_image(perk_icon_path, cache_prefix="rune_perk")

    def get_rune_style_icon(self, style_icon_path: str) -> Image.Image | None:
        """Download a rune style (tree) icon from CommunityDragon."""
        return self._get_communitydragon_image(style_icon_path, cache_prefix="rune_style")

    def _fetch_rune_perk_icon_index(self) -> dict[int, str]:
        with self._rune_index_lock:
            if self._rune_perk_icon_path_by_id is not None:
                return self._rune_perk_icon_path_by_id

            url = f"{URL_PERK_ICON_PREFIX}/v1/perks.json"
            try:
                response = requests.get(url, timeout=8)
                if response.status_code != 200:
                    self._rune_perk_icon_path_by_id = {}
                    self._rune_perk_name_by_id = {}
                    return self._rune_perk_icon_path_by_id
                payload = response.json()
            except Exception as e:
                logging.warning("DataDragon: CommunityDragon rune perk index error: %s", e)
                self._rune_perk_icon_path_by_id = {}
                self._rune_perk_name_by_id = {}
                return self._rune_perk_icon_path_by_id

            if not isinstance(payload, list):
                self._rune_perk_icon_path_by_id = {}
                self._rune_perk_name_by_id = {}
                return self._rune_perk_icon_path_by_id

            index: dict[int, str] = {}
            names: dict[int, str] = {}
            for perk in payload:
                if not isinstance(perk, dict):
                    continue
                try:
                    perk_id = int(perk.get("id") or 0)
                except (TypeError, ValueError):
                    continue
                icon_path = str(perk.get("iconPath") or "")
                if perk_id > 0 and icon_path:
                    index[perk_id] = icon_path
                    names[perk_id] = str(perk.get("name") or "")

            self._rune_perk_icon_path_by_id = index
            self._rune_perk_name_by_id = names
            return self._rune_perk_icon_path_by_id

    def get_rune_perk_icon_path(self, perk_id: Any) -> str:
        """Resolve a rune perk id to its CommunityDragon LCU asset path."""
        try:
            normalized_perk_id = int(perk_id or 0)
        except (TypeError, ValueError):
            normalized_perk_id = 0
        if normalized_perk_id <= 0:
            return ""

        return self._fetch_rune_perk_icon_index().get(normalized_perk_id, "")

    def get_rune_perk_name(self, perk_id: Any) -> str:
        """Resolve a rune perk id to its CommunityDragon display name."""
        try:
            normalized_perk_id = int(perk_id or 0)
        except (TypeError, ValueError):
            normalized_perk_id = 0
        if normalized_perk_id <= 0:
            return ""

        self._fetch_rune_perk_icon_index()
        return (self._rune_perk_name_by_id or {}).get(normalized_perk_id, "")

    @staticmethod
    def _normalize_rune_icon_size(size: Any) -> tuple[int, int]:
        if isinstance(size, tuple) and len(size) == 2:
            try:
                width = int(size[0] or 0)
                height = int(size[1] or 0)
                if width > 0 and height > 0:
                    return width, height
            except (TypeError, ValueError):
                pass
        try:
            square_size = int(size or 32)
        except (TypeError, ValueError):
            square_size = 32
        square_size = max(square_size, 1)
        return square_size, square_size

    def compose_rune_button_icon(
        self, keystone_icon_path: str, sub_style_icon_path: str = "", size: Any = 32
    ) -> Image.Image | None:
        """Return a composite image with the keystone as the main icon and the sub-style overlaid smaller."""
        target_width, target_height = self._normalize_rune_icon_size(size)
        keystone_img = self.get_rune_perk_icon(keystone_icon_path)
        if not keystone_img:
            return None
        main_size = min(target_width, target_height)
        keystone_img = keystone_img.resize((main_size, main_size), Image.LANCZOS).convert("RGBA")
        composite = Image.new("RGBA", (target_width, target_height), (0, 0, 0, 0))
        composite.paste(keystone_img, (0, (target_height - main_size) // 2), keystone_img)
        if not sub_style_icon_path:
            return composite
        sub_img = self.get_rune_style_icon(sub_style_icon_path)
        if not sub_img:
            return composite
        overlay_size = max(min(target_height // 2, target_width - main_size), 14)
        overlay_size = min(overlay_size, target_width, target_height)
        sub_img = sub_img.resize((overlay_size, overlay_size), Image.LANCZOS).convert("RGBA")
        position = (
            max(main_size - overlay_size // 3, target_width - overlay_size),
            (target_height - overlay_size) // 2,
        )
        if position[0] + overlay_size > target_width:
            position = (target_width - overlay_size, position[1])
        backing = Image.new("RGBA", composite.size, (0, 0, 0, 0))
        circle_box = (
            position[0] - 1,
            position[1] - 1,
            position[0] + overlay_size + 1,
            position[1] + overlay_size + 1,
        )
        draw = ImageDraw.Draw(backing)
        draw.ellipse(circle_box, fill=(6, 9, 14, 210), outline=(124, 137, 153, 140))
        composite.alpha_composite(backing)
        composite.paste(sub_img, position, sub_img)
        return composite

    def get_remote_image(self, url: str, *, cache_key: str) -> Image.Image | None:
        cache_key = f"{cache_key}_{hashlib.sha256(url.encode('utf-8')).hexdigest()[:16]}"
        cached = self._cache_get(cache_key)
        if cached:
            return cached

        try:
            cache_filename = "".join(char if char.isalnum() or char in {"_", "-"} else "_" for char in cache_key)
            cache_path = os.path.join(SKINS_CACHE_DIR, f"{cache_filename}.img")
            if self._is_cache_file_fresh(cache_path):
                with Image.open(cache_path) as source:
                    img = source.convert("RGBA").copy()
                self._cache_put(cache_key, img)
                return img

            os.makedirs(SKINS_CACHE_DIR, exist_ok=True)
            response = requests.get(url, stream=True, timeout=8)
            if response.status_code == 200:
                with Image.open(BytesIO(response.content)) as source:
                    img = source.convert("RGBA").copy()
                self._atomic_write_bytes(cache_path, response.content)
                self._cache_put(cache_key, img)
                self._mark_cache_file_fresh(cache_path)
                return img
        except Exception as e:
            logging.warning("DataDragon: Remote image error for %s - %s", url, e)
        return None
