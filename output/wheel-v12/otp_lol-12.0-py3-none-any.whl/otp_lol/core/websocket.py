"""
FILE NAME: src/otp_lol/core/websocket.py
GLOBAL PURPOSE:
- Maintain the live connection to the League Client Update API.
- Translate raw LCU events into application-level callbacks, state updates, and automation triggers.
- Bridge websocket transport, game-state tracking, and champion-select orchestration.

KEY FUNCTIONS:
- WebSocketManager: Own the LCU connector lifecycle and runtime state.
- _ws_loop: Run the connector inside a dedicated asyncio loop and register event handlers.
- get_effective_profile_config: Resolve global settings into one effective profile.
- _refresh_player_and_region: Keep detected account and region data synchronized with the client.

AUDIENCE & LOGIC:
Why:
This module isolates transport concerns from UI code so client reconnects, event dispatch, and automation triggers remain explicit and testable.
For whom:
Developers maintaining the live client integration, reconnect behavior, and runtime profile resolution.

DEPENDENCIES:
Used by:
- otp_lol.__main__ and src/otp_lol/ui/main_window.py through OtpLolApplication wiring.
Uses:
- Standard library: asyncio, logging, threading, time, typing
- Optional third-party libraries: lcu_driver, psutil
- Local modules: otp_lol.config, otp_lol.services.history, otp_lol.core.champ_select, otp_lol.core.game_state
"""

import asyncio
import logging
from collections.abc import Awaitable, Callable
from concurrent.futures import TimeoutError as FutureTimeoutError
from threading import Event, Lock, Thread, current_thread
from time import time
from typing import Any

try:
    from lcu_driver import Connector
    from lcu_driver.connector import Connection as LcuConnection
    from lcu_driver.connector import _return_ux_process
except ImportError:
    Connector = None
    LcuConnection = None
    _return_ux_process = None

try:
    import psutil
except ImportError:
    psutil = None

from ..config import (
    EP_CHAT_ME,
    EP_CURRENT_SUMMONER,
    EP_GAMEFLOW,
    EP_LOBBY,
    EP_LOGIN,
    EP_PERKS_CURRENT_PAGE,
    EP_PERKS_PAGES,
    EP_PERKS_STYLES,
    EP_READY_CHECK,
    EP_SESSION,
    EP_SESSION_TIMER,
    PHASE_DISPLAY_MAP,
    PLATFORM_TO_REGION,
    PRESET_ENABLED_QUEUE_IDS,
)
from ..services.history import log_history_event
from ..services.profile_config import build_effective_profile_config
from .champ_select import ChampSelectMixin
from .game_state import GameState

_LcuConnector = Connector


if _LcuConnector is not None and LcuConnection is not None and _return_ux_process is not None:

    class _StoppableLcuConnector(_LcuConnector):
        """Keep lcu-driver's process scan interruptible during application shutdown."""

        def __init__(self, *, loop, stop_event: Event):
            super().__init__(loop=loop)
            self._otp_stop_event = stop_event

        def start(self) -> None:
            try:
                while not self._otp_stop_event.is_set() and self._repeat_flag:
                    process = next(_return_ux_process(), None)
                    while not process and not self._otp_stop_event.is_set():
                        if self._otp_stop_event.wait(0.5):
                            return
                        process = next(_return_ux_process(), None)
                    if self._otp_stop_event.is_set():
                        return

                    connection = LcuConnection(self, process)
                    self.register_connection(connection)
                    self.loop.run_until_complete(connection.init())
                    if not self._repeat_flag or not self.ws.registered_uris:
                        return
            except KeyboardInterrupt:
                logging.info("LCU connector interrupted by shutdown")

else:
    _StoppableLcuConnector = None


class WebSocketManager(ChampSelectMixin):
    """Manage the LCU connector lifecycle and dispatch live client events."""

    EVENT_CONNECTED = "connected"
    EVENT_DISCONNECTED = "disconnected"
    EVENT_STATUS = "status"
    EVENT_PHASE_CHANGE = "phase_change"
    EVENT_SUMMONER_UPDATE = "summoner_update"
    EVENT_CHAMPION_PICKED = "champion_picked"
    EVENT_CHAMPION_BANNED = "champion_banned"
    EVENT_SPELLS_SET = "spells_set"
    EVENT_PLAY_AGAIN = "play_again"
    EVENT_TOAST = "toast"
    EVENT_READY_CHECK_ACCEPTED = "ready_check_accepted"
    WS_RETRY_DELAY_S = 2.0

    def __init__(
        self,
        ui_callback: Callable[[str, Any], None],
        dd,
        get_params: Callable[[], dict[str, Any]],
        update_param: Callable[[str, Any], None] | None = None,
        mutate_param: Callable[[str, Callable[[Any], Any]], None] | None = None,
    ):
        """Store shared collaborators and initialize per-run websocket state."""
        self.ui_callback = ui_callback
        self.dd = dd
        self.get_params = get_params
        self.update_param = update_param
        self.mutate_param = mutate_param
        self.state = GameState()
        self.connection = None
        self.loop: asyncio.AbstractEventLoop | None = None
        self.connector = None
        self.thread: Thread | None = None
        self.ws_active: bool = False
        self._stop_event = Event()
        self._cs_tick_lock = asyncio.Lock()
        self._skin_apply_lock = asyncio.Lock()
        self._cs_tick_requested = False
        self._tasks: set[asyncio.Task[Any]] = set()
        self._threadsafe_futures: set[Any] = set()
        self._threadsafe_futures_lock = Lock()
        self._post_game_task: asyncio.Task[Any] | None = None
        self.game_start_cooldown: float = 12.0

    def _spawn_task(self, coroutine: Awaitable[Any]) -> asyncio.Task[Any]:
        """Create a supervised task and surface unexpected background failures."""
        task = asyncio.create_task(coroutine)
        self._tasks.add(task)

        def on_done(completed: asyncio.Task[Any]) -> None:
            self._tasks.discard(completed)
            if completed is self._post_game_task:
                self._post_game_task = None
            if completed.cancelled():
                return
            exception = completed.exception()
            if exception is not None:
                logging.error(
                    "WebSocket background task failed: %s",
                    exception,
                    exc_info=(type(exception), exception, exception.__traceback__),
                )

        task.add_done_callback(on_done)
        return task

    async def _cancel_background_tasks(self) -> None:
        """Cancel supervised automation tasks before the event loop shuts down."""
        current_task = asyncio.current_task()
        pending_tasks = [task for task in self._tasks if task is not current_task and not task.done()]
        for task in pending_tasks:
            task.cancel()
        if pending_tasks:
            await asyncio.gather(*pending_tasks, return_exceptions=True)
        self._tasks.clear()
        self._post_game_task = None

    def _run_coroutine_sync(self, coroutine: Awaitable[Any], *, timeout: float, operation: str, default: Any) -> Any:
        """Run a coroutine on the LCU loop and cancel it if the caller times out."""
        if not self.loop or self.loop.is_closed() or not self.loop.is_running():
            close = getattr(coroutine, "close", None)
            if close:
                close()
            return default

        try:
            future = asyncio.run_coroutine_threadsafe(coroutine, self.loop)
        except Exception as e:
            close = getattr(coroutine, "close", None)
            if close:
                close()
            logging.debug("WebSocket: unable to schedule %s: %s", operation, e)
            return default

        try:
            return future.result(timeout=timeout)
        except FutureTimeoutError:
            future.cancel()
            logging.warning("WebSocket: %s timed out after %.1fs; coroutine cancelled.", operation, timeout)
        except Exception as e:
            logging.debug("WebSocket: %s failed: %s", operation, e)
        return default

    def _cancel_background_tasks_now(self) -> None:
        """Cancel supervised tasks synchronously when the loop cannot be re-entered."""
        current_task = asyncio.current_task() if self.loop and self.loop.is_running() else None
        for task in self._tasks:
            if task is not current_task and not task.done():
                task.cancel()
        self._tasks.clear()
        self._post_game_task = None

    def _start_post_game_task(self) -> None:
        """Start at most one post-game automation task for the current phase."""
        if self._post_game_task and not self._post_game_task.done():
            return
        self._post_game_task = self._spawn_task(self._handle_post_game())

    def _notify_ui(self, event_type: str, data: Any = None) -> None:
        self.ui_callback(event_type, data)

    async def _request_json(
        self,
        method: str,
        endpoint: str,
        *,
        expected_status: int = 200,
    ) -> Any | None:
        """Request and validate one JSON LCU payload at a transport boundary."""
        if not self.connection:
            return None
        try:
            response = await self.connection.request(method, endpoint)
            if not response or response.status != expected_status:
                return None
            return await response.json()
        except Exception as e:
            logging.debug("WebSocket: %s %s failed: %s", method.upper(), endpoint, e)
            return None

    def _log_history(
        self,
        event_type: str,
        message: str,
        details: dict[str, Any] | None = None,
        *,
        level: str | None = None,
        category: str | None = None,
        action: str | None = None,
    ) -> None:
        log_history_event(event_type, message, details, level=level, category=category, action=action)

    def start(self) -> None:
        """Start the background LCU loop if the connector is available."""
        if Connector is None:
            self._notify_ui(self.EVENT_STATUS, ("Error: 'lcu_driver' is missing.", "ERROR"))
            return
        if self.thread and self.thread.is_alive():
            return
        self._stop_event.clear()
        self.thread = Thread(target=self._ws_loop, daemon=True, name="otp-lol-lcu")
        self.thread.start()

    def stop(self) -> None:
        """Request connector shutdown and wait briefly for the worker thread to exit."""
        self._stop_event.set()
        with self._threadsafe_futures_lock:
            futures = tuple(self._threadsafe_futures)
        for future in futures:
            future.cancel()
        if self.loop and not self.loop.is_closed():
            self._run_coroutine_sync(
                self._cancel_background_tasks(),
                timeout=3,
                operation="background task cancellation",
                default=None,
            )
            if self.connector:
                self._run_coroutine_sync(
                    self.connector.stop(),
                    timeout=3,
                    operation="connector stop",
                    default=None,
                )

        if self.thread and self.thread.is_alive() and self.thread is not current_thread():
            self.thread.join(timeout=3)

    @property
    def is_active(self) -> bool:
        return self.ws_active

    def get_riot_id(self) -> str | None:
        if self.state.auto_game_name and self.state.auto_tag_line:
            return f"{self.state.auto_game_name}#{self.state.auto_tag_line}"
        return self.state.summoner or None

    def get_platform_for_websites(self) -> str:
        params = self.get_params()
        if not params.get("summoner_name_auto_detect", True):
            return params.get("manual_region", "euw").lower()
        return (
            params.get("auto_detected_region")
            or PLATFORM_TO_REGION.get((self.state.platform_routing or "").lower(), "euw")
        ).lower()

    def _get_effective_champ_select_config(self, params: dict[str, Any]) -> dict[str, str]:
        effective = self.get_effective_profile_config(params=params)
        return {
            "presets_enabled": effective["presets_enabled"],
            "selected_pick_1": effective["selected_pick_1"],
            "selected_pick_2": effective["selected_pick_2"],
            "selected_pick_3": effective["selected_pick_3"],
            "selected_ban": effective["selected_ban"],
        }

    def get_effective_profile_config(
        self,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Resolve the effective profile from global pick slots and champion picks."""
        return build_effective_profile_config(params or self.get_params())

    def get_current_summoner_id(self) -> int | None:
        try:
            return int(self.state.summoner_id or 0) or None
        except (TypeError, ValueError):
            return None

    async def _fetch_rune_pages_async(self) -> list[dict[str, Any]]:
        """Fetch all valid rune pages from the LCU."""
        if not self.connection:
            return []
        try:
            response = await self.connection.request("get", EP_PERKS_PAGES)
            if not response or response.status != 200:
                return []
            payload = await response.json()
            if not isinstance(payload, list):
                return []
            pages: list[dict[str, Any]] = []
            for page in payload:
                if not isinstance(page, dict):
                    continue
                if not page.get("isValid", True):
                    continue
                pages.append(
                    {
                        "id": page.get("id", 0),
                        "name": str(page.get("name") or ""),
                        "primaryStyleId": page.get("primaryStyleId", 0),
                        "subStyleId": page.get("subStyleId", 0),
                        "selectedPerkIds": page.get("selectedPerkIds", []),
                        "current": page.get("current", False),
                    }
                )
            return pages
        except Exception as e:
            logging.debug("Error fetching rune pages: %s", e)
            return []

    async def _fetch_rune_styles_async(self) -> dict[int, dict[str, Any]]:
        """Fetch rune style metadata from the LCU keyed by style id."""
        if not self.connection:
            return {}
        try:
            response = await self.connection.request("get", EP_PERKS_STYLES)
            if not response or response.status != 200:
                return {}
            payload = await response.json()
            if not isinstance(payload, list):
                return {}
            styles: dict[int, dict[str, Any]] = {}
            for style in payload:
                if not isinstance(style, dict):
                    continue
                style_id = self._to_int(style.get("id"))
                if style_id <= 0:
                    continue
                parsed_perks = self._extract_rune_style_perks(style)
                styles[style_id] = {
                    "name": str(style.get("name") or ""),
                    "iconPath": str(style.get("iconPath") or ""),
                    "perks": parsed_perks,
                }
            return styles
        except Exception as e:
            logging.debug("Error fetching rune styles: %s", e)
            return {}

    @staticmethod
    def _to_int(value: Any) -> int:
        try:
            return int(value or 0)
        except (TypeError, ValueError):
            return 0

    @classmethod
    def _extract_rune_style_perks(cls, style: dict[str, Any]) -> list[dict[str, Any]]:
        """Return rune perks from either the flattened or slot-based LCU style shape."""
        if not isinstance(style, dict):
            return []

        raw_perks = style.get("perks")
        if isinstance(raw_perks, list) and raw_perks:
            return [
                {
                    "id": cls._to_int(perk.get("id")),
                    "name": str(perk.get("name") or ""),
                    "iconPath": str(perk.get("iconPath") or ""),
                }
                for perk in raw_perks
                if isinstance(perk, dict)
            ]

        perks: list[dict[str, Any]] = []
        slots = style.get("slots", [])
        for slot in slots if isinstance(slots, list) else []:
            if not isinstance(slot, dict):
                continue
            slot_perks = slot.get("perks", [])
            for perk in slot_perks if isinstance(slot_perks, list) else []:
                if not isinstance(perk, dict):
                    continue
                perks.append(
                    {
                        "id": cls._to_int(perk.get("id")),
                        "name": str(perk.get("name") or ""),
                        "iconPath": str(perk.get("iconPath") or ""),
                    }
                )
        return perks

    def fetch_rune_pages(self) -> list[dict[str, Any]]:
        """Synchronous wrapper to fetch rune pages from the LCU."""
        if not self.ws_active or not self.connection or not self.loop:
            return []
        return self._run_coroutine_sync(
            self._fetch_rune_pages_async(), timeout=5, operation="rune pages fetch", default=[]
        )

    def fetch_rune_styles(self) -> dict[int, dict[str, Any]]:
        """Synchronous wrapper to fetch rune style metadata from the LCU."""
        if not self.ws_active or not self.connection or not self.loop:
            return {}
        return self._run_coroutine_sync(
            self._fetch_rune_styles_async(), timeout=5, operation="rune styles fetch", default={}
        )

    async def _fetch_current_rune_page_async(self) -> dict[str, Any] | None:
        """GET /lol-perks/v1/currentpage — return the currently active rune page or None."""
        if not self.connection:
            return None
        try:
            response = await self.connection.request("get", EP_PERKS_CURRENT_PAGE)
            if not response or response.status != 200:
                return None
            payload = await response.json()
            if not isinstance(payload, dict):
                return None
            return payload
        except Exception as e:
            logging.debug("Error fetching current rune page: %s", e)
            return None

    async def _set_rune_page_via_perks_async(self, page_data: dict[str, Any]) -> bool:
        """PUT /lol-perks/v1/pages/{id} with full page data + current: true."""
        if not self.connection:
            return False
        page_id = page_data.get("id")
        if not page_id:
            return False
        try:
            payload = dict(page_data)
            payload["current"] = True
            endpoint = f"{EP_PERKS_PAGES}/{page_id}"
            self._log_lcu_request("RUNES", "put", endpoint, payload)
            response = await self.connection.request("put", endpoint, json=payload)
            self._log_lcu_response("RUNES", "put", endpoint, response)
            return bool(response and response.status < 400)
        except Exception as e:
            logging.warning("[RUNES] PUT /lol-perks/v1/pages/%s failed: %s", page_id, e)
            return False

    async def _create_rune_page_async(self, page_data: dict[str, Any]) -> int | None:
        """POST /lol-perks/v1/pages with current: true, return the new page id or None."""
        if not self.connection:
            return None
        try:
            payload = dict(page_data)
            payload.pop("id", None)
            payload["current"] = True
            self._log_lcu_request("RUNES", "post", EP_PERKS_PAGES, payload)
            response = await self.connection.request("post", EP_PERKS_PAGES, json=payload)
            self._log_lcu_response("RUNES", "post", EP_PERKS_PAGES, response)
            if response and response.status < 400:
                created = await response.json()
                return int(created.get("id") or 0) if isinstance(created, dict) else None
            return None
        except Exception as e:
            logging.warning("[RUNES] POST /lol-perks/v1/pages failed: %s", e)
            return None

    async def _delete_rune_page_async(self, page_id: int) -> bool:
        """DELETE /lol-perks/v1/pages/{id}."""
        if not self.connection or page_id <= 0:
            return False
        try:
            endpoint = f"{EP_PERKS_PAGES}/{page_id}"
            self._log_lcu_request("RUNES", "delete", endpoint)
            response = await self.connection.request("delete", endpoint)
            self._log_lcu_response("RUNES", "delete", endpoint, response)
            return bool(response and response.status < 400)
        except Exception as e:
            logging.warning("[RUNES] DELETE /lol-perks/v1/pages/%s failed: %s", page_id, e)
            return False

    def fetch_current_rune_page(self) -> dict[str, Any] | None:
        """Sync wrapper: get the current active rune page."""
        if not self.ws_active or not self.connection or not self.loop:
            return None
        return self._run_coroutine_sync(
            self._fetch_current_rune_page_async(), timeout=5, operation="current rune page fetch", default=None
        )

    def set_rune_page_via_perks(self, page_data: dict[str, Any]) -> bool:
        """Sync wrapper: set a rune page as current via PUT."""
        if not self.ws_active or not self.connection or not self.loop:
            return False
        return self._run_coroutine_sync(
            self._set_rune_page_via_perks_async(page_data),
            timeout=5,
            operation="set rune page",
            default=False,
        )

    def create_rune_page(self, page_data: dict[str, Any]) -> int | None:
        """Sync wrapper: create a new rune page with current: true, return its id."""
        if not self.ws_active or not self.connection or not self.loop:
            return None
        return self._run_coroutine_sync(
            self._create_rune_page_async(page_data), timeout=5, operation="create rune page", default=None
        )

    def delete_rune_page(self, page_id: int) -> bool:
        """Sync wrapper: delete a rune page by id."""
        if not self.ws_active or not self.connection or not self.loop:
            return False
        return self._run_coroutine_sync(
            self._delete_rune_page_async(page_id), timeout=5, operation="delete rune page", default=False
        )

    def fetch_owned_skins_for_champion(self, champion_id: int) -> dict[str, Any]:
        if not self.ws_active or not self.connection or not self.loop:
            return {
                "ok": False,
                "message": "Unable to fetch skins. Check your League of Legends connection.",
                "owned_skins": [],
            }
        return self._run_coroutine_sync(
            self._fetch_owned_skins_for_champion(champion_id),
            timeout=8,
            operation="owned skins fetch",
            default={
                "ok": False,
                "message": "Unable to fetch skins. Check your League of Legends connection.",
                "owned_skins": [],
            },
        )

    @staticmethod
    def _inventory_skin_is_owned(item: dict[str, Any]) -> bool:
        for field in ("owned", "isOwned", "unlocked", "isUnlocked", "purchased"):
            if item.get(field) is True:
                return True
            if item.get(field) is False:
                return False

        for field in ("purchaseable", "purchasable"):
            if item.get(field) is True:
                return False

        for field in ("ownershipType", "purchaseState", "status"):
            raw_value = item.get(field)
            if raw_value in {None, ""}:
                continue
            normalized = str(raw_value).strip().lower()
            if normalized in {"owned", "ownership_owned", "rental", "rent", "free_to_play", "freetoplay", "unlocked"}:
                return True
            if normalized in {"unowned", "not_owned", "locked", "purchasable", "purchaseable"}:
                return False

        nested_ownership = item.get("ownership")
        if isinstance(nested_ownership, dict):
            if nested_ownership.get("owned") is True or nested_ownership.get("isOwned") is True:
                return True
            if nested_ownership.get("owned") is False or nested_ownership.get("isOwned") is False:
                return False

        return True

    @staticmethod
    async def _read_response_text(response: Any) -> str:
        if not response:
            return ""
        try:
            return await response.text()
        except Exception:
            return ""

    def _resolve_owned_skin_entry(
        self,
        champion_name: str,
        *,
        skin_id: int = 0,
        skin_name: str = "",
    ) -> dict[str, Any] | None:
        skin_data = None
        if skin_id > 0:
            skin_data = self.dd.resolve_skin_data(champion_name, skin_id=skin_id)
        if not skin_data and skin_name:
            skin_data = self.dd.resolve_skin_data(champion_name, skin_name=skin_name)
        return skin_data

    @staticmethod
    def _normalize_skin_collection_payload(payload: Any) -> list[dict[str, Any]]:
        if isinstance(payload, dict):
            payload = payload.get("skins") or payload.get("pickableSkins") or payload.get("inventory") or []
        if not isinstance(payload, list):
            return []
        return [item for item in payload if isinstance(item, dict)]

    def _build_owned_skin_result_entry(
        self,
        skin_data: dict[str, Any],
        *,
        fallback_skin_id: int = 0,
        fallback_skin_name: str = "",
    ) -> dict[str, Any]:
        return {
            "skin_id": int(skin_data.get("skin_id") or fallback_skin_id or 0),
            "skin_num": int(skin_data.get("skin_num") or 0),
            "skin_name": str(skin_data.get("skin_name") or fallback_skin_name or ""),
            "splash_url": skin_data.get("splash_url", ""),
            "tile_url": skin_data.get("tile_url", ""),
            "preview_url": (
                skin_data.get("tile_url")
                or skin_data.get("centered_splash_url")
                or skin_data.get("uncentered_splash_url")
                or skin_data.get("splash_url", "")
            ),
        }

    def _parse_owned_skins_payload(
        self,
        items: list[dict[str, Any]],
        champion_name: str,
        *,
        source: str,
        log_tag: str,
    ) -> dict[str, Any]:
        owned_skins: list[dict[str, Any]] = []
        unmapped_items = 0
        for item in items:
            try:
                skin_id = int(
                    item.get("id")
                    or item.get("skinId")
                    or item.get("championSkinId")
                    or item.get("selectedSkinId")
                    or 0
                )
            except (TypeError, ValueError):
                skin_id = 0
            skin_name = str(item.get("name") or item.get("displayName") or "")
            skin_data = self._resolve_owned_skin_entry(champion_name, skin_id=skin_id, skin_name=skin_name)
            if not skin_data:
                unmapped_items += 1
                logging.debug(
                    "[SKIN][OWNED] %s skin mapping failed champion=%s skin_id=%s skin_name=%s",
                    log_tag,
                    champion_name,
                    skin_id,
                    skin_name,
                )
                continue
            owned_skins.append(
                self._build_owned_skin_result_entry(
                    skin_data,
                    fallback_skin_id=skin_id,
                    fallback_skin_name=skin_name,
                )
            )

        unique_skins = []
        seen_ids = set()
        for skin in owned_skins:
            sid = int(skin.get("skin_id") or 0)
            if sid in seen_ids:
                continue
            seen_ids.add(sid)
            unique_skins.append(skin)
        logging.info(
            "[SKIN][OWNED] %s parsed champion=%s mapped=%s unmapped=%s",
            log_tag,
            champion_name,
            len(unique_skins),
            unmapped_items,
        )
        return {
            "ok": True,
            "message": "",
            "owned_skins": unique_skins,
            "source": source,
        }

    async def _fetch_owned_skins_from_inventory(
        self,
        champion_id: int,
        *,
        summoner_id: int,
    ) -> dict[str, Any]:
        endpoint = f"/lol-champions/v1/inventories/{summoner_id}/champions/{champion_id}/skins"
        champion_name = self.dd.id_to_name(champion_id) or str(champion_id)
        try:
            response = await self.connection.request("get", endpoint)
            status = response.status if response else "no-response"
            logging.info(
                "[SKIN][OWNED] Inventory request endpoint=%s summoner_id=%s champion_id=%s status=%s",
                endpoint,
                summoner_id,
                champion_id,
                status,
            )
            if not response or response.status != 200:
                body = await self._read_response_text(response)
                logging.warning("[SKIN][OWNED] Inventory request failed: %s", body or "<empty>")
                return {
                    "ok": False,
                    "message": f"LCU inventory error {status}: {body or 'empty response'}",
                    "owned_skins": [],
                    "source": "inventory",
                }
            payload = await response.json()
        except Exception as e:
            logging.exception("[SKIN][OWNED] Inventory request exception for champion_id=%s", champion_id)
            return {
                "ok": False,
                "message": str(e),
                "owned_skins": [],
                "source": "inventory",
            }

        items = self._normalize_skin_collection_payload(payload)
        logging.info("[SKIN][OWNED] Inventory payload items=%s", len(items))
        items = [item for item in items if self._inventory_skin_is_owned(item)]
        return self._parse_owned_skins_payload(items, champion_name, source="inventory", log_tag="Inventory")

    async def _fetch_owned_skins_from_pickable(self, champion_id: int) -> dict[str, Any]:
        endpoint = "/lol-champ-select/v1/pickable-skins"
        champion_name = self.dd.id_to_name(champion_id) or str(champion_id)
        try:
            response = await self.connection.request("get", endpoint)
            status = response.status if response else "no-response"
            logging.info(
                "[SKIN][OWNED] Pickable fallback endpoint=%s champion_id=%s status=%s",
                endpoint,
                champion_id,
                status,
            )
            if not response or response.status != 200:
                body = await self._read_response_text(response)
                logging.warning("[SKIN][OWNED] Pickable fallback failed: %s", body or "<empty>")
                return {
                    "ok": False,
                    "message": f"LCU pickable error {status}: {body or 'empty response'}",
                    "owned_skins": [],
                    "source": "pickable",
                }
            payload = await response.json()
        except Exception as e:
            logging.debug("[SKIN][OWNED] Pickable fallback exception: %s", e)
            return {
                "ok": False,
                "message": str(e),
                "owned_skins": [],
                "source": "pickable",
            }

        items = self._normalize_skin_collection_payload(payload)
        logging.info("[SKIN][OWNED] Pickable fallback payload items=%s", len(items))
        items = [item for item in items if int(item.get("championId") or champion_id or 0) == champion_id]
        return self._parse_owned_skins_payload(items, champion_name, source="pickable", log_tag="Pickable")

    async def _fetch_owned_skins_for_champion(self, champion_id: int) -> dict[str, Any]:
        if not self.connection:
            return {
                "ok": False,
                "message": "Unable to fetch skins. Check your League of Legends connection.",
                "owned_skins": [],
            }
        summoner_id = self.get_current_summoner_id()
        if not summoner_id:
            await self._refresh_player_and_region()
            summoner_id = self.get_current_summoner_id()

        inventory_result = None
        if summoner_id:
            inventory_result = await self._fetch_owned_skins_from_inventory(champion_id, summoner_id=summoner_id)
            if inventory_result.get("ok") and inventory_result.get("owned_skins"):
                return inventory_result
        else:
            logging.warning("[SKIN][OWNED] Missing summoner_id for champion_id=%s", champion_id)

        logging.info(
            "[SKIN][OWNED] Falling back to pickable skins champion_id=%s inventory_ok=%s inventory_count=%s",
            champion_id,
            bool(inventory_result and inventory_result.get("ok")),
            len(inventory_result.get("owned_skins", [])) if inventory_result else 0,
        )
        pickable_result = await self._fetch_owned_skins_from_pickable(champion_id)
        if pickable_result.get("ok") and pickable_result.get("owned_skins"):
            return pickable_result
        if inventory_result and inventory_result.get("ok"):
            return inventory_result
        return pickable_result or {
            "ok": False,
            "message": "Unable to fetch skins. Check your League of Legends connection.",
            "owned_skins": [],
        }

    def _store_auto_detected_values(self, riot_id: str | None, platform: str = "", region: str = "") -> None:
        if not self.update_param:
            return
        self.update_param("auto_detected_riot_id", riot_id or "")
        if platform:
            self.update_param("auto_detected_platform", platform.lower())
        if region:
            self.update_param("auto_detected_region", region.lower())

    def force_refresh_summoner(self) -> None:
        if not self._stop_event.is_set() and self.ws_active and self.connection and self.loop:
            self._submit_coroutine(self._refresh_player_and_region(), operation="summoner refresh")

    def _submit_coroutine(self, coroutine: Awaitable[Any], *, operation: str) -> None:
        """Submit a background coroutine and retain an observable completion path."""
        if not self.loop or self.loop.is_closed() or not self.loop.is_running():
            close = getattr(coroutine, "close", None)
            if close:
                close()
            return
        try:
            future = asyncio.run_coroutine_threadsafe(coroutine, self.loop)
        except Exception as e:
            close = getattr(coroutine, "close", None)
            if close:
                close()
            logging.debug("WebSocket: unable to schedule %s: %s", operation, e)
            return
        with self._threadsafe_futures_lock:
            if self._stop_event.is_set():
                future.cancel()
            else:
                self._threadsafe_futures.add(future)

        def on_done(completed) -> None:
            with self._threadsafe_futures_lock:
                self._threadsafe_futures.discard(completed)
            if completed.cancelled():
                return
            try:
                completed.result()
            except Exception:
                logging.exception("WebSocket: background %s failed", operation)

        future.add_done_callback(on_done)

    async def _handle_champ_select_session_event(self) -> None:
        """Run one champ-select tick and coalesce events received during that tick."""
        if self._cs_tick_lock.locked():
            self._cs_tick_requested = True
            return

        async with self._cs_tick_lock:
            while True:
                self._cs_tick_requested = False
                try:
                    await self._champ_select_tick()
                except Exception:
                    logging.exception("Champ-select automation tick failed; waiting for the next event.")
                if not self._cs_tick_requested:
                    return

    def _reset_ws_runtime_state(self) -> None:
        """Clear per-connection runtime fields before a reconnect or final shutdown."""
        self._cancel_background_tasks_now()
        self.connection = None
        self.ws_active = False
        self.state.current_phase = "None"
        self.state.last_reported_summoner = None
        self.state.current_queue_id = 0
        self._cs_tick_requested = False
        self.state.reset_between_games()

    def _notify_ws_disconnected(self, *, transient: bool, reason: str, status_message: str | None = None) -> None:
        """Emit a structured disconnect event unless shutdown was explicitly requested."""
        if self._stop_event.is_set():
            return
        self._notify_ui(self.EVENT_DISCONNECTED, {"transient": transient, "reason": reason})
        if status_message:
            self._notify_ui(self.EVENT_STATUS, (status_message, "WARN"))

    def _is_transient_ws_scan_error(self, exc: BaseException) -> bool:
        transient_types: tuple[type[BaseException], ...] = (ProcessLookupError,)
        if psutil is not None:
            transient_types = (
                *transient_types,
                psutil.NoSuchProcess,
                psutil.ZombieProcess,
                psutil.AccessDenied,
            )
        if isinstance(exc, transient_types):
            return True
        message = str(exc).strip().lower()
        return "process no longer exists" in message or "no such process" in message

    def _ws_loop(self) -> None:
        """Run the LCU connector in its own asyncio loop and forward LCU events to the UI thread."""
        if Connector is None:
            return

        loop = None
        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            self.loop = loop
            while not self._stop_event.is_set():
                # Recreate the connector on every retry so a broken connection does
                # not leak stale event handlers or internal transport state.
                if Connector is _LcuConnector and _StoppableLcuConnector is not None:
                    connector = _StoppableLcuConnector(loop=loop, stop_event=self._stop_event)
                else:
                    connector = Connector(loop=loop)
                self.connector = connector

                @connector.ready
                async def on_ready(connection):
                    """Store the live connection and refresh cached player context."""
                    self.connection = connection
                    self.ws_active = True
                    log_history_event(
                        "connection",
                        "LoL client detected and connection established.",
                        {"region": self.get_platform_for_websites()},
                        level="success",
                        category="Connection",
                        action="connected",
                    )
                    self._notify_ui(self.EVENT_CONNECTED, None)
                    self._notify_ui(self.EVENT_STATUS, ("LoL client detected! Ready to help.", "WS"))
                    logging.info("[WS] Connected to the LCU client.")
                    await self._refresh_player_and_region()

                @connector.close
                async def on_close(connection):
                    """Reset local state and notify the UI that the client disappeared."""
                    self._reset_ws_runtime_state()
                    if not self._stop_event.is_set():
                        log_history_event(
                            "connection",
                            "LoL client connection lost, trying to reconnect.",
                            level="warning",
                            category="Connection",
                            action="disconnected",
                        )
                        self._notify_ws_disconnected(
                            transient=False,
                            reason="client_disconnected",
                            status_message="LoL client disconnected. Trying to reconnect...",
                        )
                        logging.info("[WS] Disconnected.")
                    else:
                        logging.info("[WS] Stop requested.")

                @connector.ws.register(EP_CURRENT_SUMMONER)
                async def _ws_summoner_change(connection, event):
                    await self._refresh_player_and_region()

                @connector.ws.register(EP_CHAT_ME)
                async def _ws_chat_me_change(connection, event):
                    await self._refresh_player_and_region()

                @connector.ws.register(EP_LOGIN)
                async def _ws_login_session(connection, event):
                    data = event.data or {}
                    if data.get("status") == "SUCCEEDED":
                        self._notify_ui(self.EVENT_STATUS, ("Login detected...", "INFO"))
                        await self._refresh_player_and_region()

                @connector.ws.register(EP_GAMEFLOW)
                async def _ws_phase(connection, event):
                    # Phase changes are the main trigger for match-flow automation.
                    phase = event.data
                    if not phase:
                        return

                    previous_phase = self.state.current_phase
                    if phase != previous_phase:
                        logging.info("[PHASE] %s -> %s", previous_phase, phase)
                    self.state.current_phase = phase

                    friendly_phase = PHASE_DISPLAY_MAP.get(phase, phase)
                    self._notify_ui(self.EVENT_PHASE_CHANGE, phase)
                    self._notify_ui(self.EVENT_STATUS, (f"Status: {friendly_phase}", "INFO"))

                    if phase in ("Lobby", "Matchmaking", "ChampSelect"):
                        await self._refresh_current_queue_id()
                    if phase == "ChampSelect":
                        if previous_phase != "ChampSelect":
                            self.state.reset_between_games()
                        await self._handle_champ_select_session_event()
                    if phase in ("EndOfGame", "WaitingForStats"):
                        self._start_post_game_task()

                @connector.ws.register(EP_READY_CHECK)
                async def _ws_ready(connection, event):
                    if self.state.current_phase not in ["Matchmaking", "ReadyCheck", "None", "Lobby"]:
                        return
                    data = event.data or {}
                    params = self.get_params()
                    if (
                        params.get("auto_accept_enabled", True)
                        and data.get("state") == "InProgress"
                        and data.get("playerResponse") != "Accepted"
                    ):
                        accept_url = f"{EP_READY_CHECK}/accept"
                        logging.info("[READY] POST %s", accept_url)
                        try:
                            response = await connection.request("post", accept_url)
                        except Exception as e:
                            logging.warning("[READY] POST %s failed: %s", accept_url, e)
                            return
                        logging.info("[READY] POST %s -> %s", accept_url, getattr(response, "status", "no-response"))
                        if response and response.status < 400:
                            log_history_event(
                                "ready_check",
                                "Match automatically accepted.",
                                level="success",
                                category="Match found",
                                action="accepted",
                            )
                            self._notify_ui(self.EVENT_STATUS, ("Match accepted!", "OK"))
                            if not self.state.has_played_accept_sound:
                                self.state.has_played_accept_sound = True
                                self._notify_ui(self.EVENT_READY_CHECK_ACCEPTED, None)

                @connector.ws.register(EP_SESSION)
                async def _ws_cs_session(connection, event):
                    await self._handle_champ_select_session_event()

                @connector.ws.register(EP_SESSION_TIMER)
                async def _ws_cs_timer(connection, event):
                    # Timer polling is rate-limited because the LCU can emit frequent updates.
                    if time() - self.state._last_cs_timer_fetch > 0.2:
                        await self._champ_select_timer_tick()
                        self.state._last_cs_timer_fetch = time()

                try:
                    connector.start()
                    if self._stop_event.is_set():
                        break
                    logging.warning(
                        "[WS] Connector loop stopped unexpectedly. Retrying in %.1fs.",
                        self.WS_RETRY_DELAY_S,
                    )
                except Exception as e:
                    if self._stop_event.is_set():
                        break
                    self._reset_ws_runtime_state()
                    if self._is_transient_ws_scan_error(e):
                        logging.warning(
                            "[WS] Temporary LCU detection failure: %s. Retrying in %.1fs.",
                            e,
                            self.WS_RETRY_DELAY_S,
                        )
                        self._notify_ws_disconnected(
                            transient=True,
                            reason="lcu_process_scan_failed",
                            status_message="Temporary LCU detection failure. Waiting for League of Legends...",
                        )
                    else:
                        logging.critical("[WS] Critical error in the WebSocket loop: %s", e, exc_info=True)
                        self._notify_ws_disconnected(
                            transient=True,
                            reason="ws_loop_error",
                            status_message="LCU connection error. Trying to reconnect...",
                        )
                finally:
                    self.connector = None

                # Back off briefly between retries so the loop does not hammer process detection.
                if self._stop_event.wait(self.WS_RETRY_DELAY_S):
                    break
        finally:
            self._cancel_background_tasks_now()
            self._reset_ws_runtime_state()
            self.connector = None
            self.loop = None
            if loop is not None and not loop.is_closed():
                loop.close()

    async def _refresh_player_and_region(self) -> None:
        """Refresh detected Riot ID and routing data from whichever endpoint is currently available."""
        if not self.connection:
            return

        # Chat identity often exposes the canonical Riot ID earlier than the summoner endpoint.
        chat_me = await self._request_json("get", "/lol-chat/v1/me")
        if not isinstance(chat_me, dict):
            chat_me = None

        if isinstance(chat_me, dict):
            self.state.auto_game_name = chat_me.get("gameName")
            self.state.auto_tag_line = chat_me.get("gameTag")
            if self.state.auto_game_name and self.state.auto_tag_line:
                self.state.summoner = f"{self.state.auto_game_name}#{self.state.auto_tag_line}"
            else:
                self.state.summoner = chat_me.get("name", "Unknown")
            self.state.summoner_id = chat_me.get("summonerId")
            self.state.puuid = chat_me.get("puuid")
        else:
            payload = await self._request_json("get", "/lol-summoner/v1/current-summoner")
            if isinstance(payload, dict):
                self.state.summoner = payload.get("displayName", "Unknown")
                self.state.summoner_id = payload.get("summonerId")
                self.state.puuid = payload.get("puuid")

        if self.state.summoner != self.state.last_reported_summoner:
            self._notify_ui(self.EVENT_SUMMONER_UPDATE, self.get_riot_id())
            self._notify_ui(self.EVENT_STATUS, (f"Connected: {self.get_riot_id()}", "USER"))
            self.state.last_reported_summoner = self.state.summoner
        self._store_auto_detected_values(
            self.get_riot_id(), self.state.platform_routing, self.get_platform_for_websites()
        )

        # Region routing can come from different client endpoints depending on the client state.
        reg = await self._request_json("get", "/riotclient/get_region_locale")
        if not isinstance(reg, dict):
            reg = await self._request_json("get", "/riotclient/region-locale")
        if not isinstance(reg, dict):
            reg = None

        if isinstance(reg, dict):
            platform = (reg.get("platformId") or reg.get("region") or "").lower()
            if platform:
                self.state.platform_routing = platform
                self.state.region_routing = self._platform_to_region_routing(platform)
                self._store_auto_detected_values(
                    self.get_riot_id(),
                    platform,
                    PLATFORM_TO_REGION.get(platform, "euw"),
                )

    async def _refresh_current_queue_id(self) -> None:
        """Poll the lobby endpoint to detect the queue id before champ select starts."""
        if not self.connection:
            return
        try:
            lobby = await self._request_json("get", EP_LOBBY)
            if not isinstance(lobby, dict):
                return
            game_config = lobby.get("gameConfig") or {}
            queue_id = int(game_config.get("queueId") or 0)
            game_mode = str(game_config.get("gameMode") or "")
            logging.info("[LOBBY] queueId=%s gameMode=%r", queue_id, game_mode)
            if queue_id == self.state.current_queue_id:
                return
            self.state.current_queue_id = queue_id
            if queue_id not in PRESET_ENABLED_QUEUE_IDS:
                self._notify_ui(
                    self.EVENT_STATUS,
                    ("Presets disabled — unsupported lobby type", "GAMEMODE"),
                )
                logging.info("Queue %s — presets disabled during lobby phase.", queue_id)
        except Exception as e:
            logging.debug("Error polling lobby for queue id: %s", e)

    @staticmethod
    def _platform_to_region_routing(platform: str) -> str:
        platform = platform.lower()
        if platform in {"euw1", "eun1", "tr1", "ru"}:
            return "europe"
        if platform in {"na1", "br1", "la1", "la2", "oc1"}:
            return "americas"
        if platform in {"kr", "jp1"}:
            return "asia"
        return "europe"
