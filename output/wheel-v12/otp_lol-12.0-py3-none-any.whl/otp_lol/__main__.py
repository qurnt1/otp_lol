"""Run OTP LOL as a module or a PyInstaller script."""

import sys
from pathlib import Path

if __package__:
    from .application import main
else:
    if not getattr(sys, "frozen", False):
        sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from otp_lol.application import main

if __name__ == "__main__":
    main()
