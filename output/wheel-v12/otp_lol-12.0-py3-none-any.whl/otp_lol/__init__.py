"""OTP LOL application package."""
