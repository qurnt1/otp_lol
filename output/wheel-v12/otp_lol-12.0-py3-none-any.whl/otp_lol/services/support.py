"""Create local, privacy-conscious support bundles from existing app artifacts."""

from __future__ import annotations

import json
import os
import re
import tempfile
import zipfile
from contextlib import suppress
from typing import Any

from ..config import LOG_FILE_PATH
from .diagnostics import collect_diagnostics, diagnostics_json
from .history import get_history_entries

_SENSITIVE_KEY_RE = re.compile(
    r"(?:password|secret|token|puuid|summoner[_-]?id|riot[_-]?id|game[_-]?name|tag[_-]?line)",
    re.IGNORECASE,
)
_SENSITIVE_TEXT_RE = re.compile(
    r"((?:password|secret|token|puuid|summoner[_-]?id|riot[_-]?id|game[_-]?name|tag[_-]?line)\s*[:=]\s*)([^,\s}\]]+)",
    re.IGNORECASE,
)
_RIOT_ID_RE = re.compile(r"[^\s#]+#[A-Za-z0-9_-]+")
_WINDOWS_PATH_RE = re.compile(r"\b[A-Za-z]:\\[^\r\n\"']+")


def _redact_text(value: str) -> str:
    """Remove common account identifiers and local paths from exported text."""
    redacted = _SENSITIVE_TEXT_RE.sub(r"\1<redacted>", str(value))
    redacted = _RIOT_ID_RE.sub("<redacted-riot-id>", redacted)
    return _WINDOWS_PATH_RE.sub("<redacted-path>", redacted)


def _sanitize_value(value: Any, *, key: str = "") -> Any:
    """Recursively sanitize JSON-safe support data without mutating the source."""
    if _SENSITIVE_KEY_RE.search(key):
        return "<redacted>"
    if isinstance(value, dict):
        return {
            str(child_key): _sanitize_value(child_value, key=str(child_key)) for child_key, child_value in value.items()
        }
    if isinstance(value, list):
        return [_sanitize_value(item, key=key) for item in value]
    if isinstance(value, str):
        return _redact_text(value)
    return value


def sanitize_diagnostics(snapshot: dict[str, Any]) -> dict[str, Any]:
    """Return diagnostics safe to share outside the local machine."""
    sanitized = _sanitize_value(snapshot)
    if isinstance(sanitized, dict):
        sanitized["paths"] = {key: "<redacted>" for key in (sanitized.get("paths") or {})}
    return sanitized


def sanitize_history(entries: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Return a privacy-safe copy of history entries for support export."""
    sanitized = _sanitize_value(entries)
    return sanitized if isinstance(sanitized, list) else []


def sanitize_log_text(log_text: str) -> str:
    """Remove identifiers and Windows paths from an application log."""
    return _redact_text(log_text)


def export_support_bundle(
    destination: str,
    *,
    dd=None,
    ws_manager=None,
    params: dict[str, Any] | None = None,
) -> bool:
    """Export diagnostics, recent history, and the local log to an atomic ZIP file."""
    absolute_destination = os.path.abspath(destination)
    destination_dir = os.path.dirname(absolute_destination) or "."
    os.makedirs(destination_dir, exist_ok=True)
    file_descriptor, temp_path = tempfile.mkstemp(
        prefix="otp_lol_support_",
        suffix=".tmp",
        dir=destination_dir,
    )
    os.close(file_descriptor)

    try:
        snapshot = collect_diagnostics(dd=dd, ws_manager=ws_manager, params=params)
        with zipfile.ZipFile(temp_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("diagnostics.json", diagnostics_json(sanitize_diagnostics(snapshot)))
            archive.writestr(
                "history.json",
                json.dumps(sanitize_history(get_history_entries(limit=150)), indent=2, ensure_ascii=False),
            )
            if os.path.exists(LOG_FILE_PATH):
                with open(LOG_FILE_PATH, encoding="utf-8", errors="replace") as log_file:
                    archive.writestr("app_debug.log", sanitize_log_text(log_file.read()))
            else:
                archive.writestr("app_debug.log", "No application log file was found.\n")
            archive.writestr(
                "README.txt",
                "OTP LOL support bundle. Diagnostics, history, and logs are sanitized before export.\n",
            )
        os.replace(temp_path, absolute_destination)
        return True
    except (OSError, ValueError, zipfile.BadZipFile):
        return False
    finally:
        if os.path.exists(temp_path):
            with suppress(OSError):
                os.remove(temp_path)
