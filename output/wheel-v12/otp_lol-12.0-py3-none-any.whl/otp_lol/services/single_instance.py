"""
FILE NAME: src/otp_lol/services/single_instance.py
GLOBAL PURPOSE:
- Prevent multiple application processes from running at the same time.
- Store and clear the process lock file used by the runtime guard.
- Keep instance-detection behavior separate from launcher startup logic.

KEY FUNCTIONS:
- check_single_instance: Atomically create and lock the instance file.
- remove_lockfile: Release the lock and delete the file during shutdown.

AUDIENCE & LOGIC:
Why:
This module exists so single-instance enforcement is explicit and reusable without
mixing process checks into launcher code.
For whom:
Developers maintaining startup guards and shutdown cleanup.

DEPENDENCIES:
Used by:
- otp_lol.application.lifecycle.
Uses:
- Standard library: logging, msvcrt, os
- Third-party libraries: psutil
- Local modules: otp_lol.config
"""

import logging
import msvcrt
import os
import time
from contextlib import suppress

import psutil

from ..config import LOCKFILE_PATH

_lock_fd = None


def _is_stale_lockfile() -> bool:
    """Return True when the lock file exists but the PID inside is no longer alive."""
    try:
        with open(LOCKFILE_PATH) as f:
            pid_str = f.read().strip()
        if not pid_str:
            return time.time() - os.path.getmtime(LOCKFILE_PATH) > 2
        pid = int(pid_str)
        try:
            psutil.Process(pid)
            return False
        except (psutil.NoSuchProcess, psutil.ZombieProcess):
            return True
        except psutil.AccessDenied:
            return False
    except (OSError, ValueError, psutil.Error):
        return True


def check_single_instance() -> bool:
    """Atomically create and lock the instance file. Returns False when another instance holds the lock."""
    global _lock_fd
    if _lock_fd is not None:
        return True

    for attempt in range(2):
        file_descriptor = None
        try:
            file_descriptor = os.open(LOCKFILE_PATH, os.O_CREAT | os.O_EXCL | os.O_RDWR)
            msvcrt.locking(file_descriptor, msvcrt.LK_NBLCK, 1)
            os.write(file_descriptor, str(os.getpid()).encode())
            _lock_fd = file_descriptor
            return True
        except FileExistsError:
            if attempt == 0 and _is_stale_lockfile():
                logging.warning("Stale lock file detected, cleaning it up once before retrying.")
                _force_remove_lockfile()
                continue
            logging.info("Existing instance detected (lock file in use).")
            return False
        except OSError as e:
            logging.warning("Unable to acquire the application lock: %s", e)
            if file_descriptor is not None:
                _force_remove_lockfile()
            return False
        finally:
            if file_descriptor is not None and file_descriptor != _lock_fd:
                with suppress(OSError):
                    os.close(file_descriptor)
    return False


def remove_lockfile() -> None:
    """Release the lock and delete the file during shutdown."""
    global _lock_fd
    owns_lock = _lock_fd is not None
    try:
        if _lock_fd is not None:
            os.lseek(_lock_fd, 0, os.SEEK_SET)
            msvcrt.locking(_lock_fd, msvcrt.LK_UNLCK, 1)
            os.close(_lock_fd)
            _lock_fd = None
    except OSError as e:
        logging.debug("Error releasing lock: %s", e)
    try:
        if owns_lock and os.path.exists(LOCKFILE_PATH):
            os.remove(LOCKFILE_PATH)
    except OSError as e:
        logging.debug("Error removing lockfile: %s", e)


def _force_remove_lockfile() -> None:
    """Remove the lock file without holding a reference to it (stale recovery)."""
    try:
        if os.path.exists(LOCKFILE_PATH):
            os.remove(LOCKFILE_PATH)
    except OSError as e:
        logging.debug("Error force-removing lockfile: %s", e)
