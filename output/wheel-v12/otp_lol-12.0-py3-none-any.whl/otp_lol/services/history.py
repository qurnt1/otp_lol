"""
FILE NAME: src/otp_lol/services/history.py
GLOBAL PURPOSE:
- Persist user-visible action history to a local JSON file.
- Format raw history entries into a display-friendly structure for the UI.
- Keep event categories, labels, and detail lines consistent across the app.

KEY FUNCTIONS:
- log_history_event: Append one normalized history entry to persistent storage.
- get_history_entries: Return recent entries in reverse chronological order.
- format_history_entry: Convert a raw entry into the structure expected by the UI.

AUDIENCE & LOGIC:
Why:
This module exists so every feature records history in the same structure and the UI can render it without repeating formatting logic.
For whom:
Developers maintaining action history, event labeling, and history display behavior.

DEPENDENCIES:
Used by:
- otp_lol.core.websocket, otp_lol.core.champ_select, and otp_lol.ui.main_window.
Uses:
- Standard library: datetime, json, logging, os, typing
- Local modules: otp_lol.config
"""

import json
import logging
import os
import tempfile
import time
from datetime import UTC, datetime
from threading import RLock
from typing import Any

from ..config import HISTORY_PATH

MAX_HISTORY_ENTRIES = 250
_HISTORY_LOCK = RLock()

EVENT_DEFAULTS: dict[str, dict[str, str]] = {
    "connection": {"level": "info", "category": "Connection", "action": "client"},
    "ready_check": {"level": "success", "category": "Match found", "action": "accept"},
    "hover": {"level": "info", "category": "Champion Select", "action": "hover"},
    "ban": {"level": "success", "category": "Champion Select", "action": "ban"},
    "pick": {"level": "success", "category": "Champion Select", "action": "pick"},
    "spells": {"level": "success", "category": "Summs", "action": "set"},
    "play_again": {"level": "success", "category": "End game", "action": "play_again"},
    "error": {"level": "error", "category": "Error", "action": "error"},
}

LEVEL_LABELS = {
    "info": "Info",
    "success": "Success",
    "warning": "Warning",
    "error": "Error",
}


def _backup_unreadable_history() -> None:
    """Move a malformed history aside before a new file replaces it."""
    if not os.path.exists(HISTORY_PATH):
        return
    backup_path = f"{HISTORY_PATH}.corrupt-{os.getpid()}-{time.time_ns()}.bak"
    try:
        os.replace(HISTORY_PATH, backup_path)
        logging.warning("Backed up unreadable history to %s", backup_path)
    except OSError as e:
        logging.debug("Unable to back up unreadable history: %s", e)


CATEGORY_LABELS = {
    "Connexion": "Connection",
    "Partie trouvee": "Match found",
    "Champ Select": "Champion Select",
    "Sorts": "Summs",
    "Spells": "Summs",
    "Fin de partie": "End game",
    "Erreur": "Error",
}


def _read_history() -> list[dict[str, Any]]:
    """Read the persisted history file and return only valid dictionary entries."""
    if not os.path.exists(HISTORY_PATH):
        return []
    try:
        with open(HISTORY_PATH, encoding="utf-8") as f:
            payload = json.load(f)
        if isinstance(payload, list):
            return [entry for entry in payload if isinstance(entry, dict)]
    except (OSError, json.JSONDecodeError) as e:
        logging.debug("Unreadable history: %s", e)
        if isinstance(e, json.JSONDecodeError):
            _backup_unreadable_history()
        return []
    if not isinstance(payload, list):
        _backup_unreadable_history()
    return []


def _write_history(entries: list[dict[str, Any]]) -> None:
    """Write the bounded history list atomically so interrupted writes do not corrupt it."""
    absolute_path = os.path.abspath(HISTORY_PATH)
    directory = os.path.dirname(absolute_path) or "."
    os.makedirs(directory, exist_ok=True)
    file_descriptor, temp_path = tempfile.mkstemp(
        prefix=f".{os.path.basename(absolute_path)}.",
        suffix=".tmp",
        dir=directory,
    )
    try:
        with os.fdopen(file_descriptor, "w", encoding="utf-8", newline="") as history_file:
            json.dump(entries[-MAX_HISTORY_ENTRIES:], history_file, indent=2, ensure_ascii=False)
            history_file.flush()
            os.fsync(history_file.fileno())
        os.replace(temp_path, absolute_path)
    finally:
        if os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except OSError:
                logging.debug("Unable to remove temporary history file: %s", temp_path)


def log_history_event(
    event_type: str,
    message: str,
    details: dict[str, Any] | None = None,
    *,
    level: str | None = None,
    category: str | None = None,
    action: str | None = None,
) -> None:
    """Append a normalized history entry to the persistent history store."""
    defaults = EVENT_DEFAULTS.get(event_type, {})
    entry = {
        "timestamp": datetime.now(UTC).astimezone().isoformat(timespec="seconds"),
        "type": event_type,
        "level": level or defaults.get("level", "info"),
        "category": category or defaults.get("category", "General"),
        "action": action or defaults.get("action", event_type),
        "message": message,
        "details": details or {},
    }
    try:
        with _HISTORY_LOCK:
            entries = _read_history()
            entries.append(entry)
            _write_history(entries)
    except (OSError, TypeError, ValueError) as e:
        logging.debug("Unable to write history: %s", e)


def get_history_entries(limit: int = 100) -> list[dict[str, Any]]:
    """Return the newest history entries first, limited to the requested count."""
    try:
        normalized_limit = int(limit)
    except (TypeError, ValueError, OverflowError):
        return []
    if normalized_limit <= 0:
        return []
    with _HISTORY_LOCK:
        entries = _read_history()
        return list(reversed(entries[-normalized_limit:]))


def clear_history_entries() -> None:
    """Remove all persisted history entries."""
    try:
        with _HISTORY_LOCK:
            _write_history([])
    except (OSError, TypeError, ValueError) as e:
        logging.debug("Unable to clear history: %s", e)


def _format_timestamp(timestamp: str) -> str:
    """Convert ISO timestamps into a short local-time label for the UI."""
    if not timestamp:
        return "--:--:--"
    try:
        return datetime.fromisoformat(timestamp).strftime("%H:%M:%S")
    except ValueError:
        return timestamp[-8:] if len(timestamp) >= 8 else timestamp


def _build_detail_lines(details: dict[str, Any]) -> list[str]:
    """Convert raw history details into readable UI lines."""
    if not isinstance(details, dict):
        return []

    lines: list[str] = []
    champion = details.get("champion") or details.get("champion_name")
    if champion:
        lines.append(f"Champion: {champion}")

    spell_1 = details.get("spell_1")
    spell_2 = details.get("spell_2")
    if spell_1 or spell_2:
        lines.append(f"Summs: {spell_1 or '?'} + {spell_2 or '?'}")

    role = details.get("role") or details.get("resolved_role")
    if role:
        lines.append(f"Profile: {role}")

    region = details.get("region")
    if region:
        lines.append(f"Region: {region}")

    reason = details.get("reason")
    if reason:
        lines.append(f"Reason: {reason}")

    for key, value in details.items():
        if key in {"champion", "champion_name", "spell_1", "spell_2", "role", "resolved_role", "region", "reason"}:
            continue
        if key.endswith("_id") or key == "action_id":
            continue
        if value in ("", None, {}, []):
            continue
        lines.append(f"{str(key).replace('_', ' ').capitalize()}: {value}")

    return lines


def format_history_entry(entry: dict[str, Any]) -> dict[str, Any]:
    """Return the UI-ready representation of one raw history entry."""
    event_type = entry.get("type", "info")
    defaults = EVENT_DEFAULTS.get(event_type, {})
    level = entry.get("level") or defaults.get("level", "info")
    category = entry.get("category") or defaults.get("category", "General")
    category = CATEGORY_LABELS.get(category, category)
    return {
        "time": _format_timestamp(entry.get("timestamp", "")),
        "level": level,
        "level_label": LEVEL_LABELS.get(level, LEVEL_LABELS["info"]),
        "category": category,
        "message": entry.get("message", "Event"),
        "detail_lines": _build_detail_lines(entry.get("details", {})),
    }
