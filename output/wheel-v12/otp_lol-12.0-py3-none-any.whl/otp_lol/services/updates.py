"""
FILE NAME: src/otp_lol/services/updates.py
GLOBAL PURPOSE:
- Check whether GitHub publishes a newer application release.
- Extract release notes and download metadata for the update popup.
- Keep legacy README parsing helpers available for documentation tooling.

KEY FUNCTIONS:
- fetch_latest_release: Download the latest GitHub release through the Releases API.
- check_for_updates: Return update metadata when the remote version is newer.
- extract_version_from_readme: Find the advertised version inside README content.
- format_highlights_for_popup: Convert markdown highlights into readable plain text.

AUDIENCE & LOGIC:
Why:
This module exists so update detection stays consistent and independent from UI presentation code.
For whom:
Developers maintaining release detection, semantic version comparison, and update notes formatting.

DEPENDENCIES:
Used by:
- otp_lol.__main__ and tests.
Uses:
- Standard library: base64, logging, re, typing
- Third-party libraries: packaging, requests
- Local modules: otp_lol.config
"""

import base64
import logging
import re
from typing import Any

import requests
from packaging.version import InvalidVersion, Version

from ..config import APP_BUILD_NAME, CURRENT_VERSION, GITHUB_RELEASES_API, GITHUB_REPO_API

GITHUB_HEADERS = {
    "Accept": "application/vnd.github+json",
    "User-Agent": "OTP-LOL-UpdateChecker",
    "X-GitHub-Api-Version": "2022-11-28",
}


def _release_asset(release: dict[str, Any]) -> dict[str, str]:
    """Return the first official Windows executable asset from a release."""
    assets = release.get("assets")
    if not isinstance(assets, list):
        return {}
    for asset in assets:
        if not isinstance(asset, dict):
            continue
        name = str(asset.get("name") or "").strip()
        download_url = str(asset.get("browser_download_url") or "").strip()
        if name.lower() == f"{APP_BUILD_NAME.lower()}.exe" and download_url.startswith("https://"):
            return {"asset_name": name, "download_url": download_url}
    return {}


def fetch_latest_release() -> dict[str, Any] | None:
    """Return the latest published GitHub release payload, or None on failure."""
    try:
        response = requests.get(GITHUB_RELEASES_API, headers=GITHUB_HEADERS, timeout=10)
    except requests.RequestException as exc:
        logging.warning("[Update] GitHub Releases request failed: %s", exc)
        return None

    if response.status_code != 200:
        logging.warning("[Update] GitHub Releases API response: %s", response.status_code)
        return None
    try:
        payload = response.json()
    except ValueError as exc:
        logging.warning("[Update] GitHub Releases payload was not valid JSON: %s", exc)
        return None
    return payload if isinstance(payload, dict) else None


def fetch_remote_readme() -> str | None:
    """Return the remote README text from GitHub, or None on failure."""
    try:
        resp = requests.get(f"{GITHUB_REPO_API}/readme", headers=GITHUB_HEADERS, timeout=10)
    except requests.RequestException as exc:
        logging.warning("[Update] Remote README request failed: %s", exc)
        return None

    if resp.status_code == 200:
        try:
            data = resp.json()
        except ValueError as exc:
            logging.warning("[Update] Remote README payload was not valid JSON: %s", exc)
            return None
        content = data.get("content", "")
        encoding = data.get("encoding", "")
        if encoding == "base64" and content:
            return base64.b64decode(content).decode("utf-8", errors="replace")
        logging.warning("[Update] README content missing or unsupported encoding")
        return None

    if resp.status_code == 404:
        logging.warning("[Update] README not found in the repository")
    else:
        logging.warning("[Update] API response: %s", resp.status_code)
    return None


def check_for_updates() -> dict[str, str] | None:
    """Return remote update info when the latest GitHub release is newer."""
    try:
        logging.info("[Update] Checking GitHub Releases...")
        release = fetch_latest_release()
        if not release:
            return None

        remote_version = normalize_version(str(release.get("tag_name") or release.get("name") or ""))
        logging.info("[Update] Remote version: %s, local: %s", remote_version, CURRENT_VERSION)

        if remote_version and is_newer_version(remote_version, CURRENT_VERSION):
            asset = _release_asset(release)
            return {
                "version": remote_version,
                "highlights": str(release.get("body") or "").strip(),
                "url": str(release.get("html_url") or ""),
                **asset,
            }

    except requests.RequestException as e:
        logging.warning("[Update] Network error: %s", e)
    except (TypeError, ValueError) as e:
        logging.error("[Update] Unexpected error: %s", e)

    return None


def extract_version_from_readme(readme_text: str) -> str | None:
    """Extract version from a shields.io badge or Version Highlights header."""
    if not readme_text:
        return None

    patterns = [
        r"shields\.io/badge/version-([0-9]+(?:\.[0-9]+)*)-",
        r"shields\.io/badge/version-v?([0-9]+(?:\.[0-9]+)*)-",
        r"(?im)^##\s+Version\s+([0-9]+(?:\.[0-9]+)*)\s+Highlights\s*$",
    ]

    for pattern in patterns:
        match = re.search(pattern, readme_text, re.IGNORECASE)
        if match:
            return normalize_version(match.group(1))

    logging.warning("[Update] No version marker found in README")
    return None


def extract_highlights_section(readme_text: str, version: str) -> str:
    """Return the markdown body of the matching Version Highlights section."""
    normalized_version = normalize_version(version)
    if not readme_text or not normalized_version:
        return ""

    pattern = re.compile(
        rf"(?ims)^##\s+Version\s+{re.escape(normalized_version)}\s+Highlights\s*$\n(?P<body>.*?)(?=^\s*##\s+\S|\Z)"
    )
    match = pattern.search(readme_text)
    if not match:
        logging.warning("[Update] No highlights section found for version %s", normalized_version)
        return ""
    return match.group("body").strip()


def format_highlights_for_popup(markdown_text: str) -> str:
    """Format a README highlights block into readable plain text for the popup."""
    if not markdown_text.strip():
        return "Release notes are not available for this version yet."

    lines: list[str] = []
    previous_blank = False
    for raw_line in markdown_text.splitlines():
        stripped = raw_line.strip()
        if not stripped:
            if lines and not previous_blank:
                lines.append("")
            previous_blank = True
            continue

        cleaned = stripped.replace("`", "")
        if cleaned.startswith("- "):
            cleaned = f"• {cleaned[2:]}"
        lines.append(cleaned)
        previous_blank = False

    return "\n".join(lines).strip() or "Release notes are not available for this version yet."


def normalize_version(version: str) -> str:
    """Normalize a version like v10.0 to 10.0."""
    return (version or "").strip().lstrip("vV")


def parse_version(version: str) -> Version:
    """Parse a comparable semantic version object."""
    normalized = normalize_version(version)
    if not normalized:
        raise InvalidVersion("Empty version")
    return Version(normalized)


def is_newer_version(remote_version: str, current_version: str) -> bool:
    """Return True only if the remote version is strictly newer."""
    try:
        return parse_version(remote_version) > parse_version(current_version)
    except InvalidVersion as e:
        logging.warning("[Update] Invalid version ignored: %s", e)
        return False
