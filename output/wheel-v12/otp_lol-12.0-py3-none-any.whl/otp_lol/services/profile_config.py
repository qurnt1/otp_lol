"""
FILE NAME: src/otp_lol/services/profile_config.py
GLOBAL PURPOSE:
- Build the effective champion-select profile from persisted parameters.
- Keep pick, spell, skin, and rune slot normalization in one pure helper.

KEY FUNCTIONS:
- build_effective_profile_config: Return the normalized profile used by UI preview and LCU automation.

AUDIENCE & LOGIC:
Why:
This module prevents UI and websocket layers from duplicating configuration resolution rules.
For whom:
Developers maintaining profile settings, champion-select automation, and main-window previews.

DEPENDENCIES:
Used by:
- otp_lol.core.websocket and otp_lol.ui.main_preview
Uses:
- Standard library: typing
- Local modules: otp_lol.config.constants
"""

from typing import Any

from ..config import normalize_bool
from ..config.constants import PICK_SLOT_ORDER, SUMMONER_SPELL_MAP
from .skin_modes import build_main_skin_overrides, get_effective_skin_mode_for_slot


def build_effective_profile_config(params: dict[str, Any]) -> dict[str, Any]:
    """Return the effective profile from global pick slots and champion picks."""
    pick_slots = params.get("pick_slots", {})
    if not isinstance(pick_slots, dict):
        pick_slots = {}

    slots = {
        slot_key: _resolve_slot(params, pick_slots, slot_key, f"selected_pick_{index}")
        for index, slot_key in enumerate(PICK_SLOT_ORDER, start=1)
    }
    first_slot = slots["pick_1"]
    return {
        "presets_enabled": normalize_bool(params.get("presets_enabled", True), default=True),
        "pick_slots": slots,
        "selected_pick_1": slots["pick_1"]["champion"],
        "selected_pick_2": slots["pick_2"]["champion"],
        "selected_pick_3": slots["pick_3"]["champion"],
        "selected_ban": params.get("selected_ban", ""),
        "spell_1": first_slot.get("spell_1", ""),
        "spell_2": first_slot.get("spell_2", ""),
    }


def resolve_spell_selection(effective: dict[str, Any], slot_key: str) -> tuple[str, str, int, int, str]:
    """Resolve the current slot's configured summoner spells without cross-slot defaults."""
    slot = _get_effective_slot(effective, slot_key)
    spell_1 = str(slot.get("spell_1") or "(None)")
    spell_2 = str(slot.get("spell_2") or "(None)")
    if spell_1 == "(Aucun)":
        spell_1 = "(None)"
    if spell_2 == "(Aucun)":
        spell_2 = "(None)"
    return spell_1, spell_2, SUMMONER_SPELL_MAP.get(spell_1, 0), SUMMONER_SPELL_MAP.get(spell_2, 0), slot_key


def resolve_skin_selection(
    params: dict[str, Any],
    effective: dict[str, Any],
    slot_key: str,
) -> tuple[dict[str, Any] | None, str]:
    """Resolve the current slot's fixed or random skin configuration."""
    slot = _get_effective_slot(effective, slot_key)
    champion_name = str(slot.get("champion") or "")
    if not champion_name:
        return None, slot_key

    skin_mode = get_effective_skin_mode_for_slot(slot_key, effective, build_main_skin_overrides(params))
    if skin_mode not in {"fixed", "random"}:
        return None, slot_key

    if skin_mode == "fixed":
        skin_id = _to_int(slot.get("skin_id"))
        skin_name = str(slot.get("skin_name") or "")
        if skin_id <= 0 and not skin_name:
            return None, slot_key
        return {
            "mode": "fixed",
            "champion_name": champion_name,
            "skin_id": skin_id,
            "skin_name": skin_name,
            "skin_num": _to_int(slot.get("skin_num")),
            "skin_source_role": "GLOBAL",
        }, slot_key

    random_skin_id = _to_int(slot.get("random_skin_id"))
    random_skin_name = str(slot.get("random_skin_name") or "")
    random_skin_pool = slot.get("random_skin_pool") or []
    if random_skin_id <= 0 and not random_skin_pool and not random_skin_name:
        return None, slot_key
    return {
        "mode": "random",
        "champion_name": champion_name,
        "skin_id": random_skin_id,
        "skin_name": random_skin_name,
        "skin_num": _to_int(slot.get("random_skin_num")),
        "random_skin_pool": random_skin_pool,
        "skin_source_role": "GLOBAL",
    }, slot_key


def resolve_rune_selection(effective: dict[str, Any], slot_key: str) -> tuple[int, str, str, bool]:
    """Resolve the current slot's rune page and auto-apply setting."""
    slot = _get_effective_slot(effective, slot_key)
    return (
        _to_int(slot.get("rune_page_id")),
        str(slot.get("rune_page_name") or ""),
        slot_key,
        normalize_bool(slot.get("rune_auto_apply", True), default=True),
    )


def _resolve_slot(
    params: dict[str, Any],
    pick_slots: dict[str, Any],
    slot_key: str,
    pick_key: str,
) -> dict[str, Any]:
    slot = pick_slots.get(slot_key, {})
    if not isinstance(slot, dict):
        slot = {}
    return {
        "champion": params.get(pick_key, ""),
        "spell_1": slot.get("spell_1", ""),
        "spell_2": slot.get("spell_2", ""),
        "skin_mode": str(slot.get("skin_mode") or "none").strip().lower(),
        "skin_id": _to_int(slot.get("skin_id")),
        "skin_name": str(slot.get("skin_name") or ""),
        "skin_num": _to_int(slot.get("skin_num")),
        "random_skin_id": _to_int(slot.get("random_skin_id")),
        "random_skin_name": str(slot.get("random_skin_name") or ""),
        "random_skin_num": _to_int(slot.get("random_skin_num")),
        "random_skin_pool": _normalize_random_skin_pool(slot.get("random_skin_pool")),
        "rune_page_id": _to_int(slot.get("rune_page_id")),
        "rune_page_name": str(slot.get("rune_page_name") or ""),
        "rune_auto_apply": normalize_bool(slot.get("rune_auto_apply", True), default=True),
        "rune_keystone_path": str(slot.get("rune_keystone_path") or ""),
        "rune_sub_style_icon_path": str(slot.get("rune_sub_style_icon_path") or ""),
    }


def _normalize_random_skin_pool(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    return [dict(entry) for entry in value if isinstance(entry, dict)]


def _get_effective_slot(effective: dict[str, Any], slot_key: str) -> dict[str, Any]:
    pick_slots = effective.get("pick_slots", {})
    if not isinstance(pick_slots, dict):
        return {}
    slot = pick_slots.get(slot_key, {})
    return slot if isinstance(slot, dict) else {}


def _to_int(value: Any) -> int:
    try:
        return int(value or 0)
    except (TypeError, ValueError, OverflowError):
        return 0
