"""Collect local health checks used by the diagnostic screen and support export."""

from __future__ import annotations

import json
import os
import platform
import sys
from datetime import UTC, datetime
from typing import Any

try:
    import psutil
except ImportError:  # pragma: no cover - the packaged app includes psutil
    psutil = None

from ..config import (
    CURRENT_VERSION,
    DDRAGON_CACHE_FILE,
    HISTORY_PATH,
    LOG_FILE_PATH,
    PARAMETERS_PATH,
)

LOL_PROCESS_NAMES = {
    "leagueclient.exe",
    "leagueclientux.exe",
    "leagueclientuxrender.exe",
}


def _check(key: str, label: str, status: str, detail: str) -> dict[str, str]:
    return {"key": key, "label": label, "status": status, "detail": detail}


def _find_lol_process() -> str | None:
    """Return the first known League process name, or None when it is not running."""
    if psutil is None:
        return None
    try:
        for process in psutil.process_iter(["name"]):
            process_name = str((process.info or {}).get("name") or "").lower()
            if process_name in LOL_PROCESS_NAMES:
                return process_name
    except (OSError, psutil.Error):
        return None
    return None


def _format_path_status(path: str) -> str:
    if not path:
        return "Path unavailable"
    return path if os.path.exists(path) else f"Missing: {path}"


def collect_diagnostics(*, dd=None, ws_manager=None, params: dict[str, Any] | None = None) -> dict[str, Any]:
    """Return a JSON-safe diagnostic snapshot without making network requests."""
    process_name = _find_lol_process()
    ws_active = bool(ws_manager and getattr(ws_manager, "is_active", False))
    data_dragon_loaded = bool(dd and getattr(dd, "loaded", False))
    data_dragon_version = str(getattr(dd, "version", "") or "") if dd else ""
    champion_count = len(getattr(dd, "all_names", []) or []) if dd else 0

    if ws_active:
        client_check = _check("lol_client", "LoL client", "ok", "League client and LCU connection are active.")
        lcu_check = _check("lcu", "LCU", "ok", "LCU connection is active.")
    elif process_name:
        client_check = _check("lol_client", "LoL client", "warn", f"Detected process: {process_name}")
        lcu_check = _check("lcu", "LCU", "warn", "League client detected, waiting for an LCU connection.")
    else:
        client_check = _check("lol_client", "LoL client", "warn", "League client process was not detected.")
        lcu_check = _check("lcu", "LCU", "warn", "LCU is not connected.")

    if data_dragon_loaded and champion_count:
        ddragon_detail = f"Loaded {champion_count} champions"
        if data_dragon_version:
            ddragon_detail += f" (version {data_dragon_version})"
        ddragon_check = _check("datadragon", "Data Dragon cache", "ok", ddragon_detail)
    elif os.path.exists(DDRAGON_CACHE_FILE):
        ddragon_check = _check(
            "datadragon", "Data Dragon cache", "warn", "Cache file exists but metadata is not loaded."
        )
    else:
        ddragon_check = _check("datadragon", "Data Dragon cache", "warn", "No champion cache is available yet.")

    config_exists = os.path.exists(PARAMETERS_PATH)
    config_loaded = isinstance(params, dict) and bool(params)
    if config_exists and config_loaded:
        config_check = _check("configuration", "Configuration", "ok", "Configuration loaded and available in memory.")
    elif config_exists:
        config_check = _check(
            "configuration", "Configuration", "warn", "Configuration file exists but is not loaded in memory."
        )
    else:
        config_check = _check(
            "configuration", "Configuration", "warn", "Configuration file will be created on first launch."
        )

    checks = [client_check, lcu_check, ddragon_check, config_check]
    return {
        "generated_at": datetime.now(UTC).astimezone().isoformat(timespec="seconds"),
        "app": {
            "name": "OTP LOL",
            "version": CURRENT_VERSION,
            "python": sys.version.split()[0],
            "platform": platform.platform(),
        },
        "checks": checks,
        "paths": {
            "configuration": _format_path_status(PARAMETERS_PATH),
            "datadragon_cache": _format_path_status(DDRAGON_CACHE_FILE),
            "history": _format_path_status(HISTORY_PATH),
            "log": _format_path_status(LOG_FILE_PATH),
        },
        "runtime": {
            "lcu_active": ws_active,
            "champion_count": champion_count,
            "datadragon_version": data_dragon_version,
        },
    }


def format_diagnostics(snapshot: dict[str, Any]) -> str:
    """Format a snapshot for the existing plain-text diagnostic window."""
    lines = ["OTP LOL diagnostics", "", f"Generated: {snapshot.get('generated_at', 'unknown')}"]
    app = snapshot.get("app") or {}
    lines.extend(
        [
            f"Version: {app.get('version', 'unknown')}",
            f"Python: {app.get('python', 'unknown')}",
            f"Platform: {app.get('platform', 'unknown')}",
            "",
            "Checks:",
        ]
    )
    for check in snapshot.get("checks", []):
        lines.append(
            f"[{str(check.get('status', 'unknown')).upper()}] {check.get('label', 'Check')}: {check.get('detail', '')}"
        )
    lines.extend(["", "Paths:"])
    for label, path in (snapshot.get("paths") or {}).items():
        lines.append(f"{label}: {path}")
    return "\n".join(lines)


def diagnostics_json(snapshot: dict[str, Any]) -> str:
    """Serialize a diagnostic snapshot deterministically for support archives."""
    return json.dumps(snapshot, indent=2, ensure_ascii=False, sort_keys=True)
