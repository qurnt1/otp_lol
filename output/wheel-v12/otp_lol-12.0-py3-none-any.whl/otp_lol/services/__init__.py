"""
FILE NAME: src/otp_lol/services/__init__.py
GLOBAL PURPOSE:
- Mark `otp_lol.services` as the shared helper package.
- Group cross-cutting service modules under one namespace.
- Provide a clear package boundary for reusable runtime helpers.

KEY FUNCTIONS:
- None.

AUDIENCE & LOGIC:
Why:
This file exists so shared services can live under a dedicated package namespace.
For whom:
Developers importing reusable helper modules from `otp_lol.services`.

DEPENDENCIES:
Used by:
- Modules importing from `otp_lol.services`.
Uses:
- No runtime dependencies.
"""
