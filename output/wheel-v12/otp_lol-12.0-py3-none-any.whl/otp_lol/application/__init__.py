"""Application lifecycle and runtime bootstrap for OTP LOL."""

from .lifecycle import OtpLolApplication, main

__all__ = ["OtpLolApplication", "main"]
